import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: import.meta.env.VITE_OPENAI_API_KEY });

/**
 * Analyzuje kód a poskytne rady na zlepšení
 * @param code - Kód k analýze
 * @returns Výsledky analýzy
 */
export async function analyzeCode(code: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Jsi pokročilý kódový analytik. Proveď revizi kódu a nabídni konkrétní zlepšení zaměřená na výkon, bezpečnost a čitelnost."
        },
        {
          role: "user",
          content: `Analyzuj následující kód a poskytni konstruktivní zpětnou vazbu:\n\n${code}`
        }
      ],
    });

    return response.choices[0].message.content || "Nepodařilo se získat analýzu kódu.";
  } catch (error) {
    console.error("Chyba při analýze kódu:", error);
    throw new Error("Nepodařilo se analyzovat kód. Zkontrolujte API klíč nebo připojení.");
  }
}

/**
 * Generuje dokumentaci pro kód
 * @param code - Kód k dokumentaci
 * @returns Vygenerovaná dokumentace
 */
export async function generateDocumentation(code: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Jsi specialista na dokumentaci kódu. Vytvoř podrobnou dokumentaci s popisem funkcionality, parametrů, návratových hodnot a příkladů použití."
        },
        {
          role: "user",
          content: `Vygeneruj dokumentaci pro následující kód:\n\n${code}`
        }
      ],
    });

    return response.choices[0].message.content || "Nepodařilo se vygenerovat dokumentaci.";
  } catch (error) {
    console.error("Chyba při generování dokumentace:", error);
    throw new Error("Nepodařilo se vygenerovat dokumentaci. Zkontrolujte API klíč nebo připojení.");
  }
}

/**
 * Pomáhá řešit problémy s kódem
 * @param code - Problematický kód
 * @param errorMessage - Chybová zpráva
 * @returns Navrhované řešení
 */
export async function debugCode(code: string, errorMessage: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Jsi zkušený debugger. Analyzuj zdrojový kód a související chybové zprávy, identifikuj problémy a navrhni opravy."
        },
        {
          role: "user",
          content: `Pomoz mi opravit tento kód. Chybová zpráva: "${errorMessage}"\n\nZdrojový kód:\n\n${code}`
        }
      ],
    });

    return response.choices[0].message.content || "Nepodařilo se získat debug pomoc.";
  } catch (error) {
    console.error("Chyba při debugování kódu:", error);
    throw new Error("Nepodařilo se debugovat kód. Zkontrolujte API klíč nebo připojení.");
  }
}

/**
 * Generuje nové funkce nebo komponenty na základě popisu
 * @param description - Popis požadované funkcionality
 * @param framework - Použitý framework (např. 'react', 'express')
 * @returns Vygenerovaný kód
 */
export async function generateFeature(description: string, framework: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `Jsi expert na vývoj v ${framework}. Vytvoř kód, který splňuje zadané požadavky s důrazem na efektivitu, bezpečnost a moderní praktiky.`
        },
        {
          role: "user",
          content: `Vytvoř ${framework} komponentu/funkci podle tohoto popisu: "${description}"`
        }
      ],
    });

    return response.choices[0].message.content || "Nepodařilo se vygenerovat funkci.";
  } catch (error) {
    console.error("Chyba při generování funkce:", error);
    throw new Error("Nepodařilo se vygenerovat funkci. Zkontrolujte API klíč nebo připojení.");
  }
}

/**
 * Obecný dotaz na AI asistenta
 * @param query - Dotaz uživatele
 * @returns Odpověď
 */
export async function askQuestion(query: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Jsi pomocník pro vývojáře, zaměřený na programování a technické informace. Poskytuj jasné, informativní a stručné odpovědi."
        },
        {
          role: "user",
          content: query
        }
      ],
    });

    return response.choices[0].message.content || "Nepodařilo se získat odpověď.";
  } catch (error) {
    console.error("Chyba při dotazu:", error);
    throw new Error("Nepodařilo se získat odpověď. Zkontrolujte API klíč nebo připojení.");
  }
}

/**
 * Generuje testovací případy pro zadaný kód
 * @param code - Kód, pro který generujeme testy
 * @param testFramework - Testovací framework (např. 'jest', 'mocha')
 * @returns Vygenerované testy
 */
export async function generateTests(code: string, testFramework: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `Jsi specialista na testování s frameworkem ${testFramework}. Vytvoř komplexní sadu testů pro poskytnutý kód, pokrývající různé scénáře včetně hraničních případů a ošetření chyb.`
        },
        {
          role: "user",
          content: `Vygeneruj testy v ${testFramework} pro následující kód:\n\n${code}`
        }
      ],
    });

    return response.choices[0].message.content || "Nepodařilo se vygenerovat testy.";
  } catch (error) {
    console.error("Chyba při generování testů:", error);
    throw new Error("Nepodařilo se vygenerovat testy. Zkontrolujte API klíč nebo připojení.");
  }
}
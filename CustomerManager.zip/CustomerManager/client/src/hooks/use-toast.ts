// Definování simple verzí toastů pro oznámení
import { useState } from "react";

type ToastType = "default" | "success" | "error" | "warning" | "info" | "destructive";

interface Toast {
  id: string;
  title: string;
  description?: string;
  variant?: ToastType;
  duration?: number;
}

type ToastOptions = Omit<Toast, "id">;

export function useToast() {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const toast = (options: ToastOptions) => {
    const id = Math.random().toString(36).substring(2, 9);
    const newToast: Toast = {
      id,
      title: options.title,
      description: options.description,
      variant: options.variant || "default",
      duration: options.duration || 5000,
    };

    setToasts((prevToasts) => [...prevToasts, newToast]);

    // Automaticky odstraní toast po určité době
    setTimeout(() => {
      setToasts((prevToasts) => prevToasts.filter((toast) => toast.id !== id));
    }, newToast.duration);

    return id;
  };

  const dismissToast = (id: string) => {
    setToasts((prevToasts) => prevToasts.filter((toast) => toast.id !== id));
  };

  return {
    toast,
    toasts,
    dismissToast,
  };
}
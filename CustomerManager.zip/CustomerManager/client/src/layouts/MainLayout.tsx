import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  Users,
  Building2,
  TrendingUp,
  Menu,
  X,
  FileDown,
  Code,
  Terminal,
  Settings,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import ExportDialog from "@/components/ExportDialog";

interface MainLayoutProps {
  children: React.ReactNode;
}

const MainLayout = ({ children }: MainLayoutProps) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [location, setLocation] = useLocation();
  const [exportDialogOpen, setExportDialogOpen] = useState(false);
  
  // Close sidebar when changing route on mobile
  useEffect(() => {
    if (window.innerWidth < 768) {
      setSidebarOpen(false);
    }
  }, [location]);
  
  // Set sidebar to open on large screens by default
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setSidebarOpen(true);
      } else {
        setSidebarOpen(false);
      }
    };
    
    handleResize();
    window.addEventListener("resize", handleResize);
    
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);
  
  const getPageTitle = () => {
    switch (location) {
      case "/":
        return "Dashboard";
      case "/contacts":
        return "Správa kontaktů";
      case "/companies":
        return "Správa společností";
      case "/opportunities":
        return "Správa příležitostí";
      case "/developer":
        return "Vývojářský panel";
      case "/dev-system":
        return "Vývojářský systém";
      default:
        return "";
    }
  };
  
  return (
    <div className="flex flex-col w-full h-screen overflow-hidden">
      {/* Mobile header */}
      <div className="bg-white border-b border-gray-200 lg:hidden">
        <div className="px-4 py-3 flex items-center justify-between">
          <button 
            onClick={() => setSidebarOpen(!sidebarOpen)} 
            className="text-gray-500 focus:outline-none focus:text-gray-700"
          >
            <Menu className="h-6 w-6" />
          </button>
          <div className="text-xl font-semibold text-primary">CRM Systém</div>
          <div className="w-6"></div>
        </div>
      </div>
      
      {/* Main container */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar overlay */}
        {sidebarOpen && (
          <div 
            className="fixed inset-0 z-20 bg-black bg-opacity-50 lg:hidden" 
            onClick={() => setSidebarOpen(false)}
          ></div>
        )}
        
        {/* Sidebar */}
        <div 
          className={`fixed lg:relative z-30 inset-y-0 left-0 w-64 bg-secondary text-white transition-transform duration-300 transform ${
            sidebarOpen ? "translate-x-0" : "-translate-x-full"
          } lg:translate-x-0 lg:flex lg:flex-col flex-shrink-0`}
        >
          <div className="flex items-center justify-between px-4 py-6 border-b border-neutral-700">
            <div className="text-2xl font-semibold">CRM Systém</div>
            <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-white">
              <X className="h-6 w-6" />
            </button>
          </div>
          
          <div className="overflow-y-auto flex-1">
            <nav className="px-4 pt-4 space-y-1">
              <Link href="/">
                <a className={`flex items-center px-4 py-3 text-sm font-medium rounded-md cursor-pointer transition-all duration-200 ${
                  location === "/" ? "bg-neutral-700" : "hover:bg-neutral-800"
                }`}>
                  <LayoutDashboard className="mr-3 h-5 w-5" />
                  Dashboard
                </a>
              </Link>
              
              <Link href="/contacts">
                <a className={`flex items-center px-4 py-3 text-sm font-medium rounded-md cursor-pointer transition-all duration-200 ${
                  location === "/contacts" ? "bg-neutral-700" : "hover:bg-neutral-800"
                }`}>
                  <Users className="mr-3 h-5 w-5" />
                  Kontakty
                </a>
              </Link>
              
              <Link href="/companies">
                <a className={`flex items-center px-4 py-3 text-sm font-medium rounded-md cursor-pointer transition-all duration-200 ${
                  location === "/companies" ? "bg-neutral-700" : "hover:bg-neutral-800"
                }`}>
                  <Building2 className="mr-3 h-5 w-5" />
                  Společnosti
                </a>
              </Link>
              
              <Link href="/opportunities">
                <a className={`flex items-center px-4 py-3 text-sm font-medium rounded-md cursor-pointer transition-all duration-200 ${
                  location === "/opportunities" ? "bg-neutral-700" : "hover:bg-neutral-800"
                }`}>
                  <TrendingUp className="mr-3 h-5 w-5" />
                  Příležitosti
                </a>
              </Link>
              
              <div className="py-2 my-2 border-t border-neutral-700"></div>
              
              <Link href="/developer">
                <a className={`flex items-center px-4 py-3 text-sm font-medium rounded-md cursor-pointer transition-all duration-200 ${
                  location === "/developer" ? "bg-neutral-700" : "hover:bg-neutral-800"
                }`}>
                  <Code className="mr-3 h-5 w-5" />
                  Vývojářský panel
                </a>
              </Link>
              
              <Link href="/dev-system">
                <a className={`flex items-center px-4 py-3 text-sm font-medium rounded-md cursor-pointer transition-all duration-200 ${
                  location === "/dev-system" ? "bg-neutral-700" : "hover:bg-neutral-800"
                }`}>
                  <Terminal className="mr-3 h-5 w-5" />
                  Vývojářský systém
                </a>
              </Link>
            </nav>
          </div>
          
          <div className="p-4 border-t border-neutral-700">
            <Button 
              onClick={() => setExportDialogOpen(true)}
              className="w-full justify-start"
              variant="default"
            >
              <FileDown className="mr-3 h-5 w-5" />
              Exportovat data
            </Button>
          </div>
        </div>
        
        {/* Main content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="bg-white shadow">
            <div className="px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
              <h1 className="text-lg font-semibold text-gray-900">
                {getPageTitle()}
              </h1>
              
              {/* Action buttons will be added in the child components */}
            </div>
          </div>
          
          {/* Page content */}
          <div className="flex-1 overflow-auto p-4 sm:px-6 lg:px-8 bg-gray-100">
            {children}
          </div>
        </div>
      </div>
      
      <ExportDialog open={exportDialogOpen} onOpenChange={setExportDialogOpen} />
    </div>
  );
};

export default MainLayout;

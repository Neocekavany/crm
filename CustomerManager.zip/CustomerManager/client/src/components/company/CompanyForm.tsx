import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import { Company, companyValidationSchema, InsertCompany } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

interface CompanyFormProps {
  open: boolean;
  company: Company | null;
  onOpenChange: (open: boolean) => void;
}

export default function CompanyForm({ open, company, onOpenChange }: CompanyFormProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const isEditing = !!company;
  
  const form = useForm<InsertCompany>({
    resolver: zodResolver(companyValidationSchema),
    defaultValues: {
      name: "",
      address: "",
      industry: "",
      website: "",
      employees: undefined,
      revenue: "",
      status: "prospect",
      contactPerson: "",
      notes: "",
    },
  });
  
  useEffect(() => {
    if (company) {
      form.reset({
        name: company.name,
        address: company.address || "",
        industry: company.industry,
        website: company.website || "",
        employees: company.employees,
        revenue: company.revenue || "",
        status: company.status,
        contactPerson: company.contactPerson || "",
        notes: company.notes || "",
      });
    } else {
      form.reset({
        name: "",
        address: "",
        industry: "",
        website: "",
        employees: undefined,
        revenue: "",
        status: "prospect",
        contactPerson: "",
        notes: "",
      });
    }
  }, [company, form]);
  
  const createMutation = useMutation({
    mutationFn: async (data: InsertCompany) => {
      const res = await apiRequest("POST", "/api/companies", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/companies'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      onOpenChange(false);
      toast({
        title: "Společnost vytvořena",
        description: "Nová společnost byla úspěšně přidána",
      });
    },
    onError: (error) => {
      toast({
        title: "Chyba při vytváření společnosti",
        description: error instanceof Error ? error.message : "Neznámá chyba",
        variant: "destructive",
      });
    },
  });
  
  const updateMutation = useMutation({
    mutationFn: async (data: { id: number; company: InsertCompany }) => {
      const res = await apiRequest("PUT", `/api/companies/${data.id}`, data.company);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/companies'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      onOpenChange(false);
      toast({
        title: "Společnost aktualizována",
        description: "Společnost byla úspěšně aktualizována",
      });
    },
    onError: (error) => {
      toast({
        title: "Chyba při aktualizaci společnosti",
        description: error instanceof Error ? error.message : "Neznámá chyba",
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: InsertCompany) => {
    if (isEditing && company) {
      updateMutation.mutate({ id: company.id, company: data });
    } else {
      createMutation.mutate(data);
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Upravit společnost" : "Přidat novou společnost"}</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Název společnosti</FormLabel>
                  <FormControl>
                    <Input placeholder="Název společnosti" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="address"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Adresa</FormLabel>
                  <FormControl>
                    <Input placeholder="Adresa" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="industry"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Obor podnikání</FormLabel>
                    <FormControl>
                      <Input placeholder="Obor podnikání" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="website"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Webové stránky</FormLabel>
                    <FormControl>
                      <Input placeholder="Webové stránky" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="employees"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Počet zaměstnanců</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder="Počet zaměstnanců"
                        {...field}
                        onChange={(e) => field.onChange(e.target.value === '' ? undefined : parseInt(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="revenue"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Roční obrat</FormLabel>
                    <FormControl>
                      <Input placeholder="Roční obrat" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="contactPerson"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Kontaktní osoba</FormLabel>
                    <FormControl>
                      <Input placeholder="Kontaktní osoba" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      value={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Vyberte status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="client">Klient</SelectItem>
                        <SelectItem value="prospect">Prospekt</SelectItem>
                        <SelectItem value="lead">Lead</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Poznámky</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Poznámky ke společnosti"
                      className="resize-none"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => onOpenChange(false)}
              >
                Zrušit
              </Button>
              <Button 
                type="submit"
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {(createMutation.isPending || updateMutation.isPending) 
                  ? "Ukládání..." 
                  : "Uložit"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

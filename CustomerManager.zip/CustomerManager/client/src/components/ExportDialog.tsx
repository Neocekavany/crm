import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";

interface ExportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function ExportDialog({ open, onOpenChange }: ExportDialogProps) {
  const { toast } = useToast();
  const [exportType, setExportType] = useState("csv");
  const [isExporting, setIsExporting] = useState(false);

  const handleExport = async () => {
    setIsExporting(true);
    try {
      // Simulace exportu dat
      await new Promise((resolve) => setTimeout(resolve, 1500));
      
      toast({
        title: "Export dokončen",
        description: `Data byla úspěšně exportována ve formátu ${exportType.toUpperCase()}.`,
      });
      
      onOpenChange(false);
    } catch (error) {
      toast({
        title: "Chyba při exportu",
        description: "Nepodařilo se exportovat data. Zkuste to prosím později.",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Exportovat data</DialogTitle>
          <DialogDescription>
            Vyberte formát pro export dat z CRM systému.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4">
          <RadioGroup value={exportType} onValueChange={setExportType}>
            <div className="flex items-start space-x-2 space-y-0">
              <RadioGroupItem value="csv" id="csv" />
              <div className="grid gap-1.5">
                <Label htmlFor="csv" className="font-medium">CSV</Label>
                <p className="text-sm text-muted-foreground">
                  Standardní formát, který lze otevřít v Excel, Google Sheets a dalších tabulkových procesorech.
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-2 space-y-0 mt-3">
              <RadioGroupItem value="excel" id="excel" />
              <div className="grid gap-1.5">
                <Label htmlFor="excel" className="font-medium">Excel (XLSX)</Label>
                <p className="text-sm text-muted-foreground">
                  Nativní formát pro Microsoft Excel s podporou pro více listů a formátování.
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-2 space-y-0 mt-3">
              <RadioGroupItem value="json" id="json" />
              <div className="grid gap-1.5">
                <Label htmlFor="json" className="font-medium">JSON</Label>
                <p className="text-sm text-muted-foreground">
                  Datový formát pro vývojáře a programové zpracování.
                </p>
              </div>
            </div>
          </RadioGroup>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Zrušit
          </Button>
          <Button onClick={handleExport} disabled={isExporting}>
            {isExporting ? "Exportuji..." : "Exportovat"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
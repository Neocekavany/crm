import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQueryClient, useMutation, useQuery } from "@tanstack/react-query";
import { Opportunity, opportunityValidationSchema, InsertOpportunity } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";

interface OpportunityFormProps {
  open: boolean;
  opportunity: Opportunity | null;
  onOpenChange: (open: boolean) => void;
}

export default function OpportunityForm({ open, opportunity, onOpenChange }: OpportunityFormProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const isEditing = !!opportunity;
  
  const { data: companies } = useQuery({ 
    queryKey: ['/api/companies'],
    enabled: open, // Only fetch when dialog is open
  });
  
  const { data: contacts } = useQuery({ 
    queryKey: ['/api/contacts'],
    enabled: open, // Only fetch when dialog is open
  });
  
  const form = useForm<InsertOpportunity>({
    resolver: zodResolver(opportunityValidationSchema),
    defaultValues: {
      name: "",
      company: "",
      contact: "",
      value: "",
      probability: 50,
      status: "discovery",
      expectedCloseDate: "",
      notes: "",
    },
  });
  
  useEffect(() => {
    if (opportunity) {
      form.reset({
        name: opportunity.name,
        company: opportunity.company,
        contact: opportunity.contact || "",
        value: opportunity.value,
        probability: opportunity.probability,
        status: opportunity.status,
        expectedCloseDate: opportunity.expectedCloseDate instanceof Date
          ? formatDateForInput(opportunity.expectedCloseDate)
          : formatDateForInput(new Date(opportunity.expectedCloseDate)),
        notes: opportunity.notes || "",
      });
    } else {
      form.reset({
        name: "",
        company: "",
        contact: "",
        value: "",
        probability: 50,
        status: "discovery",
        expectedCloseDate: "",
        notes: "",
      });
    }
  }, [opportunity, form]);
  
  // Format date for input field
  const formatDateForInput = (date: Date) => {
    return date.toISOString().split('T')[0];
  };
  
  const createMutation = useMutation({
    mutationFn: async (data: InsertOpportunity) => {
      const res = await apiRequest("POST", "/api/opportunities", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      onOpenChange(false);
      toast({
        title: "Příležitost vytvořena",
        description: "Nová příležitost byla úspěšně přidána",
      });
    },
    onError: (error) => {
      toast({
        title: "Chyba při vytváření příležitosti",
        description: error instanceof Error ? error.message : "Neznámá chyba",
        variant: "destructive",
      });
    },
  });
  
  const updateMutation = useMutation({
    mutationFn: async (data: { id: number; opportunity: InsertOpportunity }) => {
      const res = await apiRequest("PUT", `/api/opportunities/${data.id}`, data.opportunity);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      onOpenChange(false);
      toast({
        title: "Příležitost aktualizována",
        description: "Příležitost byla úspěšně aktualizována",
      });
    },
    onError: (error) => {
      toast({
        title: "Chyba při aktualizaci příležitosti",
        description: error instanceof Error ? error.message : "Neznámá chyba",
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: InsertOpportunity) => {
    if (isEditing && opportunity) {
      updateMutation.mutate({ id: opportunity.id, opportunity: data });
    } else {
      createMutation.mutate(data);
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Upravit příležitost" : "Přidat novou příležitost"}</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Název příležitosti</FormLabel>
                  <FormControl>
                    <Input placeholder="Název příležitosti" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="company"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Společnost</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Vyberte společnost" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {companies?.map((company) => (
                        <SelectItem key={company.id} value={company.name}>
                          {company.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="contact"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Kontaktní osoba</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Vyberte kontakt" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="">Žádný kontakt</SelectItem>
                      {contacts?.map((contact) => (
                        <SelectItem key={contact.id} value={`${contact.firstName} ${contact.lastName}`}>
                          {contact.firstName} {contact.lastName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="value"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Hodnota</FormLabel>
                    <FormControl>
                      <Input placeholder="např. 150 000 Kč" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Fáze</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      value={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Vyberte fázi" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="discovery">Objevování</SelectItem>
                        <SelectItem value="proposal">Nabídka</SelectItem>
                        <SelectItem value="negotiation">Vyjednávání</SelectItem>
                        <SelectItem value="won">Vyhráno</SelectItem>
                        <SelectItem value="lost">Prohráno</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="probability"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Pravděpodobnost: {field.value}%</FormLabel>
                  <FormControl>
                    <Slider
                      defaultValue={[field.value]}
                      min={0}
                      max={100}
                      step={5}
                      onValueChange={(values) => {
                        field.onChange(values[0]);
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="expectedCloseDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Očekávané datum uzavření</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Poznámky</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Poznámky k příležitosti"
                      className="resize-none"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => onOpenChange(false)}
              >
                Zrušit
              </Button>
              <Button 
                type="submit"
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {(createMutation.isPending || updateMutation.isPending) 
                  ? "Ukládání..." 
                  : "Uložit"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

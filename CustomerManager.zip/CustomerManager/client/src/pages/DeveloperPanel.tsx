import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Code, FileText, Bug, Sparkles, HelpCircle, TestTube } from "lucide-react";

// Interface pro odpovědi API
interface ApiResponse {
  isLoading: boolean;
  error: string | null;
  data: string | null;
}

/**
 * Panel pro vývojáře s AI funkcemi
 */
export default function DeveloperPanel() {
  const { toast } = useToast();
  
  // Záložky a formulářová data
  const [activeTab, setActiveTab] = useState("code-analysis");
  
  // Code Analysis
  const [codeToAnalyze, setCodeToAnalyze] = useState("");
  const [analysisResult, setAnalysisResult] = useState<ApiResponse>({
    isLoading: false,
    error: null,
    data: null
  });
  
  // Documentation
  const [codeToDocument, setCodeToDocument] = useState("");
  const [documentationResult, setDocumentationResult] = useState<ApiResponse>({
    isLoading: false,
    error: null,
    data: null
  });
  
  // Debug
  const [codeToDebug, setCodeToDebug] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [debugResult, setDebugResult] = useState<ApiResponse>({
    isLoading: false,
    error: null,
    data: null
  });
  
  // Generate Feature
  const [featureDescription, setFeatureDescription] = useState("");
  const [framework, setFramework] = useState("react");
  const [featureResult, setFeatureResult] = useState<ApiResponse>({
    isLoading: false,
    error: null,
    data: null
  });
  
  // Ask Question
  const [question, setQuestion] = useState("");
  const [questionResult, setQuestionResult] = useState<ApiResponse>({
    isLoading: false,
    error: null,
    data: null
  });
  
  // Generate Tests
  const [codeToTest, setCodeToTest] = useState("");
  const [testFramework, setTestFramework] = useState("jest");
  const [testsResult, setTestsResult] = useState<ApiResponse>({
    isLoading: false,
    error: null,
    data: null
  });

  // Funkce pro volání API
  const callApi = async (endpoint: string, data: any, setResult: React.Dispatch<React.SetStateAction<ApiResponse>>) => {
    setResult({
      isLoading: true,
      error: null,
      data: null
    });
    
    try {
      const response = await fetch(`/api/dev/${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Něco se pokazilo');
      }
      
      setResult({
        isLoading: false,
        error: null,
        data: Object.values(result)[0] as string // Získá první hodnotu z výsledku (analysis, documentation, atd.)
      });
    } catch (error) {
      setResult({
        isLoading: false,
        error: error.message,
        data: null
      });
      
      toast({
        title: "Chyba",
        description: `Během operace došlo k chybě: ${error.message}`,
        variant: "destructive",
      });
    }
  };
  
  // Handlery pro jednotlivé funkce
  const handleAnalyzeCode = () => {
    if (!codeToAnalyze.trim()) {
      toast({
        title: "Chybí kód",
        description: "Prosím, vložte kód k analýze",
        variant: "destructive",
      });
      return;
    }
    
    callApi('analyze-code', { code: codeToAnalyze }, setAnalysisResult);
  };
  
  const handleGenerateDocumentation = () => {
    if (!codeToDocument.trim()) {
      toast({
        title: "Chybí kód",
        description: "Prosím, vložte kód pro generování dokumentace",
        variant: "destructive",
      });
      return;
    }
    
    callApi('generate-documentation', { code: codeToDocument }, setDocumentationResult);
  };
  
  const handleDebugCode = () => {
    if (!codeToDebug.trim() || !errorMessage.trim()) {
      toast({
        title: "Chybí informace",
        description: "Prosím, vložte kód a chybovou zprávu",
        variant: "destructive",
      });
      return;
    }
    
    callApi('debug-code', { code: codeToDebug, errorMessage }, setDebugResult);
  };
  
  const handleGenerateFeature = () => {
    if (!featureDescription.trim()) {
      toast({
        title: "Chybí popis",
        description: "Prosím, popište požadovanou funkcionalitu",
        variant: "destructive",
      });
      return;
    }
    
    callApi('generate-feature', { description: featureDescription, framework }, setFeatureResult);
  };
  
  const handleAskQuestion = () => {
    if (!question.trim()) {
      toast({
        title: "Chybí dotaz",
        description: "Prosím, zadejte váš dotaz",
        variant: "destructive",
      });
      return;
    }
    
    callApi('ask-question', { query: question }, setQuestionResult);
  };
  
  const handleGenerateTests = () => {
    if (!codeToTest.trim()) {
      toast({
        title: "Chybí kód",
        description: "Prosím, vložte kód pro generování testů",
        variant: "destructive",
      });
      return;
    }
    
    callApi('generate-tests', { code: codeToTest, testFramework }, setTestsResult);
  };
  
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>AI Vývojářský Panel</CardTitle>
          <CardDescription>
            Panel s využitím umělé inteligence pro vývojáře CRM systému. 
            Pomocí OpenAI modelu GPT-4o můžete analyzovat kód, generovat dokumentaci, 
            debugovat problémy a mnohem více.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="code-analysis" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <TabsList className="grid grid-cols-3 md:grid-cols-6 gap-2">
              <TabsTrigger value="code-analysis" className="flex items-center space-x-2">
                <Code className="h-4 w-4" />
                <span className="hidden md:inline">Analýza kódu</span>
              </TabsTrigger>
              <TabsTrigger value="documentation" className="flex items-center space-x-2">
                <FileText className="h-4 w-4" />
                <span className="hidden md:inline">Dokumentace</span>
              </TabsTrigger>
              <TabsTrigger value="debug" className="flex items-center space-x-2">
                <Bug className="h-4 w-4" />
                <span className="hidden md:inline">Debug</span>
              </TabsTrigger>
              <TabsTrigger value="feature" className="flex items-center space-x-2">
                <Sparkles className="h-4 w-4" />
                <span className="hidden md:inline">Funkce</span>
              </TabsTrigger>
              <TabsTrigger value="question" className="flex items-center space-x-2">
                <HelpCircle className="h-4 w-4" />
                <span className="hidden md:inline">Dotazy</span>
              </TabsTrigger>
              <TabsTrigger value="tests" className="flex items-center space-x-2">
                <TestTube className="h-4 w-4" />
                <span className="hidden md:inline">Testy</span>
              </TabsTrigger>
            </TabsList>

            {/* Analýza kódu */}
            <TabsContent value="code-analysis" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="code-analysis">Kód k analýze</Label>
                <Textarea
                  id="code-analysis"
                  placeholder="Vložte svůj kód zde..."
                  className="min-h-[200px] font-mono"
                  value={codeToAnalyze}
                  onChange={(e) => setCodeToAnalyze(e.target.value)}
                />
              </div>
              
              <Button 
                onClick={handleAnalyzeCode} 
                disabled={analysisResult.isLoading}
                className="w-full"
              >
                {analysisResult.isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Analyzovat kód
              </Button>
              
              {analysisResult.error && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-800">
                  {analysisResult.error}
                </div>
              )}
              
              {analysisResult.data && (
                <div className="p-4 bg-gray-50 border border-gray-200 rounded-md whitespace-pre-line">
                  <h3 className="font-semibold mb-2">Výsledky analýzy:</h3>
                  {analysisResult.data}
                </div>
              )}
            </TabsContent>

            {/* Dokumentace */}
            <TabsContent value="documentation" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="code-documentation">Kód pro dokumentaci</Label>
                <Textarea
                  id="code-documentation"
                  placeholder="Vložte svůj kód zde..."
                  className="min-h-[200px] font-mono"
                  value={codeToDocument}
                  onChange={(e) => setCodeToDocument(e.target.value)}
                />
              </div>
              
              <Button 
                onClick={handleGenerateDocumentation} 
                disabled={documentationResult.isLoading}
                className="w-full"
              >
                {documentationResult.isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Generovat dokumentaci
              </Button>
              
              {documentationResult.error && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-800">
                  {documentationResult.error}
                </div>
              )}
              
              {documentationResult.data && (
                <div className="p-4 bg-gray-50 border border-gray-200 rounded-md whitespace-pre-line">
                  <h3 className="font-semibold mb-2">Vygenerovaná dokumentace:</h3>
                  {documentationResult.data}
                </div>
              )}
            </TabsContent>

            {/* Debug */}
            <TabsContent value="debug" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="code-debug">Problematický kód</Label>
                <Textarea
                  id="code-debug"
                  placeholder="Vložte svůj kód zde..."
                  className="min-h-[150px] font-mono"
                  value={codeToDebug}
                  onChange={(e) => setCodeToDebug(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="error-message">Chybová zpráva</Label>
                <Textarea
                  id="error-message"
                  placeholder="Vložte chybovou zprávu zde..."
                  className="min-h-[80px]"
                  value={errorMessage}
                  onChange={(e) => setErrorMessage(e.target.value)}
                />
              </div>
              
              <Button 
                onClick={handleDebugCode} 
                disabled={debugResult.isLoading}
                className="w-full"
              >
                {debugResult.isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Debugovat kód
              </Button>
              
              {debugResult.error && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-800">
                  {debugResult.error}
                </div>
              )}
              
              {debugResult.data && (
                <div className="p-4 bg-gray-50 border border-gray-200 rounded-md whitespace-pre-line">
                  <h3 className="font-semibold mb-2">Navrhované řešení:</h3>
                  {debugResult.data}
                </div>
              )}
            </TabsContent>

            {/* Generování funkce */}
            <TabsContent value="feature" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="feature-description">Popis funkcionality</Label>
                <Textarea
                  id="feature-description"
                  placeholder="Popište požadovanou funkcionalitu..."
                  className="min-h-[150px]"
                  value={featureDescription}
                  onChange={(e) => setFeatureDescription(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="framework">Framework</Label>
                <Select value={framework} onValueChange={setFramework}>
                  <SelectTrigger>
                    <SelectValue placeholder="Vyberte framework" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="react">React</SelectItem>
                    <SelectItem value="express">Express</SelectItem>
                    <SelectItem value="react+typescript">React + TypeScript</SelectItem>
                    <SelectItem value="express+typescript">Express + TypeScript</SelectItem>
                    <SelectItem value="vanilla">JavaScript (Vanilla)</SelectItem>
                    <SelectItem value="nodejs">Node.js</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={handleGenerateFeature} 
                disabled={featureResult.isLoading}
                className="w-full"
              >
                {featureResult.isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Generovat funkci
              </Button>
              
              {featureResult.error && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-800">
                  {featureResult.error}
                </div>
              )}
              
              {featureResult.data && (
                <div className="p-4 bg-gray-50 border border-gray-200 rounded-md whitespace-pre-line">
                  <h3 className="font-semibold mb-2">Vygenerovaný kód:</h3>
                  <pre className="overflow-auto p-4 bg-slate-900 text-slate-50 rounded-md">
                    {featureResult.data}
                  </pre>
                </div>
              )}
            </TabsContent>

            {/* Dotaz na AI */}
            <TabsContent value="question" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="question">Otázka</Label>
                <Textarea
                  id="question"
                  placeholder="Napište svůj dotaz ohledně vývoje CRM..."
                  className="min-h-[150px]"
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                />
              </div>
              
              <Button 
                onClick={handleAskQuestion} 
                disabled={questionResult.isLoading}
                className="w-full"
              >
                {questionResult.isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Položit dotaz
              </Button>
              
              {questionResult.error && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-800">
                  {questionResult.error}
                </div>
              )}
              
              {questionResult.data && (
                <div className="p-4 bg-gray-50 border border-gray-200 rounded-md whitespace-pre-line">
                  <h3 className="font-semibold mb-2">Odpověď:</h3>
                  {questionResult.data}
                </div>
              )}
            </TabsContent>

            {/* Generování testů */}
            <TabsContent value="tests" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="code-tests">Kód pro generování testů</Label>
                <Textarea
                  id="code-tests"
                  placeholder="Vložte svůj kód zde..."
                  className="min-h-[200px] font-mono"
                  value={codeToTest}
                  onChange={(e) => setCodeToTest(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="test-framework">Testovací framework</Label>
                <Select value={testFramework} onValueChange={setTestFramework}>
                  <SelectTrigger>
                    <SelectValue placeholder="Vyberte testovací framework" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="jest">Jest</SelectItem>
                    <SelectItem value="mocha">Mocha</SelectItem>
                    <SelectItem value="cypress">Cypress</SelectItem>
                    <SelectItem value="testing-library">React Testing Library</SelectItem>
                    <SelectItem value="vitest">Vitest</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={handleGenerateTests} 
                disabled={testsResult.isLoading}
                className="w-full"
              >
                {testsResult.isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Generovat testy
              </Button>
              
              {testsResult.error && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-800">
                  {testsResult.error}
                </div>
              )}
              
              {testsResult.data && (
                <div className="p-4 bg-gray-50 border border-gray-200 rounded-md whitespace-pre-line">
                  <h3 className="font-semibold mb-2">Vygenerované testy:</h3>
                  <pre className="overflow-auto p-4 bg-slate-900 text-slate-50 rounded-md">
                    {testsResult.data}
                  </pre>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
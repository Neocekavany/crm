import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { DataTable } from "@/components/ui/data-table";
import { ColumnDef } from "@tanstack/react-table";
import { PlusCircle, Pencil, Trash2 } from "lucide-react";
import { Opportunity } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Progress } from "@/components/ui/progress";
import { format } from "date-fns";
import OpportunityForm from "@/components/opportunity/OpportunityForm";

export default function Opportunities() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [opportunityFormOpen, setOpportunityFormOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [currentOpportunity, setCurrentOpportunity] = useState<Opportunity | null>(null);
  
  const { data: opportunities, isLoading } = useQuery<Opportunity[]>({
    queryKey: ['/api/opportunities'],
  });
  
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/opportunities/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      toast({
        title: "Příležitost smazána",
        description: "Příležitost byla úspěšně odstraněna",
      });
      setDeleteDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Chyba při mazání příležitosti",
        description: error instanceof Error ? error.message : "Neznámá chyba",
        variant: "destructive",
      });
    },
  });
  
  const handleDelete = (opportunity: Opportunity) => {
    setCurrentOpportunity(opportunity);
    setDeleteDialogOpen(true);
  };
  
  const handleEdit = (opportunity: Opportunity) => {
    setCurrentOpportunity(opportunity);
    setOpportunityFormOpen(true);
  };
  
  const handleAdd = () => {
    setCurrentOpportunity(null);
    setOpportunityFormOpen(true);
  };
  
  const confirmDelete = () => {
    if (currentOpportunity) {
      deleteMutation.mutate(currentOpportunity.id);
    }
  };
  
  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'discovery': return 'Objevování';
      case 'proposal': return 'Nabídka';
      case 'negotiation': return 'Vyjednávání';
      case 'won': return 'Vyhráno';
      case 'lost': return 'Prohráno';
      default: return status;
    }
  };
  
  const getStatusVariant = (status: string) => {
    switch (status) {
      case 'discovery': return 'default';
      case 'proposal': return 'secondary';
      case 'negotiation': return 'warning';
      case 'won': return 'success';
      case 'lost': return 'destructive';
      default: return 'secondary';
    }
  };
  
  const columns: ColumnDef<Opportunity>[] = [
    {
      accessorKey: "name",
      header: "Příležitost",
      cell: ({ row }) => (
        <div className="text-sm font-medium text-gray-900">{row.original.name}</div>
      ),
    },
    {
      accessorKey: "company",
      header: "Společnost/Kontakt",
      cell: ({ row }) => {
        const opportunity = row.original;
        return (
          <div>
            <div className="text-sm text-gray-900">{opportunity.company}</div>
            <div className="text-sm text-gray-500">{opportunity.contact || '-'}</div>
          </div>
        );
      },
    },
    {
      accessorKey: "value",
      header: "Hodnota",
      cell: ({ row }) => (
        <div className="text-sm text-gray-900">{row.original.value}</div>
      ),
    },
    {
      accessorKey: "probability",
      header: "Pravděpodobnost",
      cell: ({ row }) => {
        const probability = row.original.probability;
        return (
          <div>
            <Progress value={probability} className="h-2 w-full" />
            <div className="text-xs text-gray-500 mt-1">{probability}%</div>
          </div>
        );
      },
    },
    {
      accessorKey: "status",
      header: "Fáze",
      cell: ({ row }) => {
        const status = row.original.status;
        return (
          <Badge variant={getStatusVariant(status) as any}>
            {getStatusLabel(status)}
          </Badge>
        );
      },
    },
    {
      accessorKey: "expectedCloseDate",
      header: "Uzavření",
      cell: ({ row }) => {
        const date = row.original.expectedCloseDate;
        return (
          <div className="text-sm text-gray-500">
            {date ? format(new Date(date), 'dd.MM.yyyy') : '-'}
          </div>
        );
      },
    },
    {
      id: "actions",
      header: () => <div className="text-right">Akce</div>,
      cell: ({ row }) => (
        <div className="flex justify-end gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              handleEdit(row.original);
            }}
          >
            <Pencil className="h-4 w-4 text-primary" />
            <span className="sr-only">Upravit</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              handleDelete(row.original);
            }}
          >
            <Trash2 className="h-4 w-4 text-red-600" />
            <span className="sr-only">Smazat</span>
          </Button>
        </div>
      ),
    },
  ];
  
  return (
    <>
      <div className="flex justify-end mb-4">
        <Button onClick={handleAdd}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Přidat příležitost
        </Button>
      </div>
      
      <DataTable
        columns={columns}
        data={opportunities || []}
        searchPlaceholder="Hledat příležitosti..."
        searchColumn="name"
        filterOptions={[
          {
            name: "Fáze",
            options: [
              { label: "Objevování", value: "discovery" },
              { label: "Nabídka", value: "proposal" },
              { label: "Vyjednávání", value: "negotiation" },
              { label: "Vyhráno", value: "won" },
              { label: "Prohráno", value: "lost" },
            ],
            column: "status",
          },
        ]}
        onRowClick={handleEdit}
      />
      
      <OpportunityForm
        open={opportunityFormOpen}
        opportunity={currentOpportunity}
        onOpenChange={setOpportunityFormOpen}
      />
      
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Opravdu chcete smazat tuto příležitost?</AlertDialogTitle>
            <AlertDialogDescription>
              Tuto akci nelze vrátit zpět. Příležitost bude trvale odstraněna z našeho systému.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Zrušit</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">
              Smazat
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

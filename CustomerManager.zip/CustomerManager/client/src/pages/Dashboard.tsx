import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import DashboardCard from "@/components/dashboard/DashboardCard";
import ActivityFeed from "@/components/dashboard/ActivityFeed";
import { 
  Users, 
  Building2, 
  CheckCircle, 
  DollarSign, 
  LayoutDashboard 
} from "lucide-react";
import { formatCurrency } from "@/utils/format";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { data: contacts, isLoading: contactsLoading } = useQuery({
    queryKey: ['/api/contacts'],
  });
  
  const { data: companies, isLoading: companiesLoading } = useQuery({
    queryKey: ['/api/companies'],
  });
  
  const { data: opportunities, isLoading: opportunitiesLoading } = useQuery({
    queryKey: ['/api/opportunities'],
  });
  
  const { data: activities, isLoading: activitiesLoading } = useQuery({
    queryKey: ['/api/activities'],
    queryFn: async () => {
      const res = await fetch('/api/activities?limit=5');
      if (!res.ok) throw new Error('Failed to fetch activities');
      return res.json();
    },
  });
  
  // Calculate dashboard metrics
  const activeContactsCount = contacts?.filter(c => c.status === 'active').length || 0;
  const clientCompaniesCount = companies?.filter(c => c.status === 'client').length || 0;
  const wonOpportunitiesCount = opportunities?.filter(o => o.status === 'won').length || 0;
  
  const totalOpportunitiesValue = opportunities?.reduce((sum, o) => {
    // Skip lost opportunities
    if (o.status === 'lost') return sum;
    
    // Extract numeric value from string like "850 000 Kč"
    const numericValue = parseInt(o.value.replace(/[^\d]/g, '')) || 0;
    
    // Apply probability factor
    return sum + (numericValue * (o.probability / 100));
  }, 0) || 0;
  
  const isLoading = contactsLoading || companiesLoading || opportunitiesLoading;

  return (
    <div className="space-y-6">
      {/* Dashboard Cards */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <DashboardCard
          title="Aktivních kontaktů"
          value={isLoading ? undefined : activeContactsCount}
          icon={<Users className="h-6 w-6 text-primary" />}
          linkText="Zobrazit všechny kontakty"
          linkHref="/contacts"
        />
        
        <DashboardCard
          title="Klientských společností"
          value={isLoading ? undefined : clientCompaniesCount}
          icon={<Building2 className="h-6 w-6 text-primary" />}
          linkText="Zobrazit všechny společnosti"
          linkHref="/companies"
        />
        
        <DashboardCard
          title="Vyhraných příležitostí"
          value={isLoading ? undefined : wonOpportunitiesCount}
          icon={<CheckCircle className="h-6 w-6 text-green-600" />}
          iconBgClass="bg-green-100"
          linkText="Zobrazit všechny příležitosti"
          linkHref="/opportunities"
        />
        
        <DashboardCard
          title="Očekávaná hodnota"
          value={isLoading ? undefined : `${formatCurrency(totalOpportunitiesValue)} Kč`}
          icon={<DollarSign className="h-6 w-6 text-primary" />}
          linkText="Zobrazit detaily"
          linkHref="/opportunities"
        />
      </div>
      
      {/* Recent Activities */}
      <Card>
        <div className="px-6 py-5 border-b border-gray-200">
          <h3 className="text-lg font-medium leading-6 text-gray-900">Nedávné aktivity</h3>
        </div>
        <CardContent className="p-6">
          {activitiesLoading ? (
            <div className="space-y-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-start space-x-3">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-1/3" />
                    <Skeleton className="h-3 w-1/4" />
                    <Skeleton className="h-10 w-full" />
                  </div>
                </div>
              ))}
            </div>
          ) : activities?.length ? (
            <ActivityFeed activities={activities} />
          ) : (
            <div className="py-10 flex flex-col items-center justify-center">
              <LayoutDashboard className="h-16 w-16 text-gray-400 mb-4" />
              <p className="text-gray-500 text-xl">Žádné nedávné aktivity</p>
              <p className="text-gray-400 mt-2">Aktivity se zobrazí, jakmile provedete změny</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

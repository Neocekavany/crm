import React, { useState, useEffect, useRef } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { 
  Code, FileText, History, Play, Save, Folder, FileCode, RefreshCw,
  Settings, Terminal, Eye, Download, Upload, ChevronRight, ChevronDown,
  Search, HardDrive, PlusCircle, Trash2, Copy, Sparkles
} from "lucide-react";

// Typy pro soubory a adresáře
interface FileItem {
  id: string;
  name: string;
  type: 'file';
  path: string;
  content?: string;
  language?: string;
}

interface DirectoryItem {
  id: string;
  name: string;
  type: 'directory';
  path: string;
  children: (FileItem | DirectoryItem)[];
  expanded?: boolean;
}

type FileSystemItem = FileItem | DirectoryItem;

// Historie změn
interface HistoryItem {
  id: string;
  timestamp: Date;
  description: string;
  user: string;
  changes: string;
}

// Rozhraní pro API odpovědi
interface ApiResponse {
  isLoading: boolean;
  error: string | null;
  data: any | null;
}

/**
 * DevSystem - Kompletní vývojářské prostředí s editorem kódu, průzkumníkem souborů a nástrojem AI
 */
export default function DevSystem() {
  const { toast } = useToast();
  const [activeMainTab, setActiveMainTab] = useState("editor");
  const [activeEditorTab, setActiveEditorTab] = useState("code");
  const [activeAITab, setActiveAITab] = useState("code-analysis");
  
  // Stav pro editor kódu
  const [currentFile, setCurrentFile] = useState<FileItem | null>(null);
  const [code, setCode] = useState("");
  const [fileLanguage, setFileLanguage] = useState("javascript");
  const [savedCode, setSavedCode] = useState("");
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  
  // Stav pro průzkumník souborů
  const [fileSystem, setFileSystem] = useState<FileSystemItem[]>([]);
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({});
  const [searchQuery, setSearchQuery] = useState("");
  
  // Stav pro historii změn
  const [history, setHistory] = useState<HistoryItem[]>([]);
  
  // Stav pro náhled aplikace
  const [previewUrl, setPreviewUrl] = useState("http://localhost:3000");
  const [isPreviewLoading, setIsPreviewLoading] = useState(false);
  const previewIframeRef = useRef<HTMLIFrameElement>(null);
  
  // Stav pro AI funkce
  const [codeToAnalyze, setCodeToAnalyze] = useState("");
  const [analysisResult, setAnalysisResult] = useState<ApiResponse>({
    isLoading: false,
    error: null,
    data: null
  });
  
  const [codeToDocument, setCodeToDocument] = useState("");
  const [documentationResult, setDocumentationResult] = useState<ApiResponse>({
    isLoading: false,
    error: null,
    data: null
  });
  
  const [codeToDebug, setCodeToDebug] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [debugResult, setDebugResult] = useState<ApiResponse>({
    isLoading: false,
    error: null,
    data: null
  });
  
  const [featureDescription, setFeatureDescription] = useState("");
  const [framework, setFramework] = useState("react");
  const [featureResult, setFeatureResult] = useState<ApiResponse>({
    isLoading: false,
    error: null,
    data: null
  });
  
  // Inicializace - načtení dat při prvním renderování
  useEffect(() => {
    fetchFileSystem();
    fetchHistory();
  }, []);
  
  // Sledování změn v kódu
  useEffect(() => {
    if (currentFile && code !== savedCode) {
      setHasUnsavedChanges(true);
    } else {
      setHasUnsavedChanges(false);
    }
  }, [code, savedCode, currentFile]);
  
  // Funkce pro komunikaci s API
  const fetchFileSystem = async () => {
    try {
      // Zde by bylo volání na backend API pro získání stromu souborů
      // Pro testovací účely vrátíme ukázkový systém souborů
      const mockFileSystem: FileSystemItem[] = [
        {
          id: "1",
          name: "client",
          type: "directory",
          path: "/client",
          expanded: true,
          children: [
            {
              id: "2",
              name: "src",
              type: "directory",
              path: "/client/src",
              expanded: true,
              children: [
                {
                  id: "3",
                  name: "pages",
                  type: "directory",
                  path: "/client/src/pages",
                  expanded: true,
                  children: [
                    {
                      id: "4",
                      name: "Dashboard.tsx",
                      type: "file",
                      path: "/client/src/pages/Dashboard.tsx",
                      language: "typescript"
                    },
                    {
                      id: "5",
                      name: "Contacts.tsx",
                      type: "file",
                      path: "/client/src/pages/Contacts.tsx",
                      language: "typescript"
                    }
                  ]
                },
                {
                  id: "6",
                  name: "components",
                  type: "directory",
                  path: "/client/src/components",
                  expanded: false,
                  children: [
                    {
                      id: "7",
                      name: "ui",
                      type: "directory",
                      path: "/client/src/components/ui",
                      children: []
                    }
                  ]
                }
              ]
            }
          ]
        },
        {
          id: "8",
          name: "server",
          type: "directory",
          path: "/server",
          expanded: false,
          children: [
            {
              id: "9",
              name: "crm-server.js",
              type: "file",
              path: "/server/crm-server.js",
              language: "javascript"
            },
            {
              id: "10",
              name: "api-openai.js",
              type: "file",
              path: "/server/api-openai.js",
              language: "javascript"
            }
          ]
        }
      ];
      
      setFileSystem(mockFileSystem);
      
      // Inicializace expandovaných složek
      const initialExpandedFolders: Record<string, boolean> = {};
      const processItems = (items: FileSystemItem[]) => {
        items.forEach(item => {
          if (item.type === 'directory') {
            initialExpandedFolders[item.id] = !!item.expanded;
            processItems(item.children);
          }
        });
      };
      
      processItems(mockFileSystem);
      setExpandedFolders(initialExpandedFolders);
    } catch (error) {
      console.error("Chyba při načítání systému souborů:", error);
      toast({
        title: "Chyba",
        description: "Nepodařilo se načíst systém souborů",
        variant: "destructive",
      });
    }
  };
  
  const fetchHistory = async () => {
    try {
      // Zde by bylo volání na backend API pro získání historie změn
      // Pro testovací účely vrátíme ukázkovou historii
      const mockHistory: HistoryItem[] = [
        {
          id: "1",
          timestamp: new Date(2025, 4, 18, 15, 30),
          description: "Přidán nový AI modul pro vývojáře",
          user: "admin",
          changes: "Přidány soubory api-openai.js a DeveloperPanel.tsx"
        },
        {
          id: "2",
          timestamp: new Date(2025, 4, 18, 14, 45),
          description: "Oprava chyby v komponentě pro kontakty",
          user: "admin",
          changes: "Opraveno zpracování formuláře v ContactForm.tsx"
        },
        {
          id: "3",
          timestamp: new Date(2025, 4, 17, 11, 20),
          description: "Vylepšení dashboardu",
          user: "admin",
          changes: "Přidány nové grafy a statistiky na stránku Dashboard"
        }
      ];
      
      setHistory(mockHistory);
    } catch (error) {
      console.error("Chyba při načítání historie:", error);
      toast({
        title: "Chyba",
        description: "Nepodařilo se načíst historii změn",
        variant: "destructive",
      });
    }
  };
  
  const fetchFileContent = async (file: FileItem) => {
    try {
      // Zde by bylo volání na backend API pro získání obsahu souboru
      // Pro testovací účely vrátíme ukázkový obsah
      const mockContent = file.name.includes("Dashboard") 
        ? `import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="p-6">
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p>Vítejte v CRM systému!</p>
        </CardContent>
      </Card>
    </div>
  );
}`
        : file.name.includes("server") 
        ? `/**
 * Hlavní server pro CRM aplikaci
 */
          
import express from 'express';
import cors from 'cors';
import { join } from 'path';

const app = express();
app.use(cors());
app.use(express.json());

// API endpointy
app.get('/api/test', (req, res) => {
  res.json({
    message: 'API funguje správně',
    timestamp: new Date()
  });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(\`Server běží na portu \${port}\`);
});`
        : "// Obsah souboru " + file.path;
      
      setCurrentFile(file);
      setCode(mockContent);
      setSavedCode(mockContent);
      setFileLanguage(file.language || "javascript");
    } catch (error) {
      console.error("Chyba při načítání obsahu souboru:", error);
      toast({
        title: "Chyba",
        description: `Nepodařilo se načíst obsah souboru ${file.name}`,
        variant: "destructive",
      });
    }
  };
  
  const saveCurrentFile = async () => {
    if (!currentFile) return;
    
    try {
      // Zde by bylo volání na backend API pro uložení souboru
      // Pro testovací účely jen předstíráme uložení
      console.log(`Ukládám soubor ${currentFile.path} s obsahem:`, code);
      
      toast({
        title: "Úspěch",
        description: `Soubor ${currentFile.name} byl úspěšně uložen`,
      });
      
      setSavedCode(code);
      setHasUnsavedChanges(false);
      
      // Přidání záznamu do historie
      const newHistoryItem: HistoryItem = {
        id: Date.now().toString(),
        timestamp: new Date(),
        description: `Úprava souboru ${currentFile.name}`,
        user: "admin",
        changes: "Změny v obsahu souboru"
      };
      
      setHistory([newHistoryItem, ...history]);
    } catch (error) {
      console.error("Chyba při ukládání souboru:", error);
      toast({
        title: "Chyba",
        description: `Nepodařilo se uložit soubor ${currentFile.name}`,
        variant: "destructive",
      });
    }
  };
  
  const refreshPreview = () => {
    if (previewIframeRef.current) {
      setIsPreviewLoading(true);
      previewIframeRef.current.src = previewUrl;
    }
  };
  
  const handlePreviewLoad = () => {
    setIsPreviewLoading(false);
  };
  
  const toggleFolder = (folderId: string) => {
    setExpandedFolders(prev => ({
      ...prev,
      [folderId]: !prev[folderId]
    }));
  };

  // Funkce pro volání AI služeb
  const callAiApi = async (endpoint: string, data: any, setResult: React.Dispatch<React.SetStateAction<ApiResponse>>) => {
    setResult({
      isLoading: true,
      error: null,
      data: null
    });
    
    try {
      const response = await fetch(`/api/dev/${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Něco se pokazilo');
      }
      
      setResult({
        isLoading: false,
        error: null,
        data: Object.values(result)[0]
      });
    } catch (error) {
      setResult({
        isLoading: false,
        error: error.message,
        data: null
      });
      
      toast({
        title: "Chyba",
        description: `Během operace došlo k chybě: ${error.message}`,
        variant: "destructive",
      });
    }
  };
  
  // Handlery pro AI funkce
  const handleAnalyzeCode = () => {
    if (!codeToAnalyze.trim()) {
      toast({
        title: "Chybí kód",
        description: "Prosím, vložte kód k analýze",
        variant: "destructive",
      });
      return;
    }
    
    callAiApi('analyze-code', { code: codeToAnalyze }, setAnalysisResult);
  };
  
  const handleGenerateDocumentation = () => {
    if (!codeToDocument.trim()) {
      toast({
        title: "Chybí kód",
        description: "Prosím, vložte kód pro generování dokumentace",
        variant: "destructive",
      });
      return;
    }
    
    callAiApi('generate-documentation', { code: codeToDocument }, setDocumentationResult);
  };
  
  const handleDebugCode = () => {
    if (!codeToDebug.trim() || !errorMessage.trim()) {
      toast({
        title: "Chybí informace",
        description: "Prosím, vložte kód a chybovou zprávu",
        variant: "destructive",
      });
      return;
    }
    
    callAiApi('debug-code', { code: codeToDebug, errorMessage }, setDebugResult);
  };
  
  const handleGenerateFeature = () => {
    if (!featureDescription.trim()) {
      toast({
        title: "Chybí popis",
        description: "Prosím, popište požadovanou funkcionalitu",
        variant: "destructive",
      });
      return;
    }
    
    callAiApi('generate-feature', { description: featureDescription, framework }, setFeatureResult);
  };
  
  // Renderování komponenty průzkumníku souborů
  const renderFileTree = (items: FileSystemItem[], depth = 0) => {
    const filteredItems = searchQuery
      ? items.filter(item => 
          item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (item.type === 'directory' && 
           renderFileTree(item.children).some(Boolean))
        )
      : items;
  
    return filteredItems.map((item) => {
      const paddingLeft = `${depth * 16}px`;
      
      if (item.type === 'directory') {
        const isExpanded = expandedFolders[item.id];
        return (
          <div key={item.id}>
            <div 
              className="flex items-center py-1 px-2 hover:bg-secondary/20 cursor-pointer"
              style={{ paddingLeft }}
              onClick={() => toggleFolder(item.id)}
            >
              {isExpanded ? (
                <ChevronDown className="h-4 w-4 mr-1" />
              ) : (
                <ChevronRight className="h-4 w-4 mr-1" />
              )}
              <Folder className="h-4 w-4 mr-2 text-blue-500" />
              <span>{item.name}</span>
            </div>
            {isExpanded && (
              <div>{renderFileTree(item.children, depth + 1)}</div>
            )}
          </div>
        );
      } else {
        return (
          <div 
            key={item.id}
            className={`flex items-center py-1 px-2 hover:bg-secondary/20 cursor-pointer ${
              currentFile?.id === item.id ? 'bg-secondary/30' : ''
            }`}
            style={{ paddingLeft }}
            onClick={() => fetchFileContent(item)}
          >
            <FileCode className="h-4 w-4 mr-2 text-yellow-500" />
            <span>{item.name}</span>
          </div>
        );
      }
    });
  };

  return (
    <div className="h-[calc(100vh-120px)] overflow-hidden">
      <Tabs defaultValue="editor" value={activeMainTab} onValueChange={setActiveMainTab} className="h-full">
        <div className="border-b">
          <TabsList className="w-full justify-start rounded-none border-b px-4">
            <TabsTrigger value="editor" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none">
              <Code className="mr-2 h-4 w-4" />
              Editor kódu
            </TabsTrigger>
            <TabsTrigger value="ai" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none">
              <Sparkles className="mr-2 h-4 w-4" />
              AI Asistent
            </TabsTrigger>
            <TabsTrigger value="preview" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none">
              <Eye className="mr-2 h-4 w-4" />
              Náhled
            </TabsTrigger>
          </TabsList>
        </div>

        {/* Editor kódu */}
        <TabsContent value="editor" className="mt-0 h-full">
          <ResizablePanelGroup direction="horizontal" className="h-full">
            {/* Levý panel - Průzkumník souborů */}
            <ResizablePanel defaultSize={20} minSize={15} maxSize={30} className="border-r">
              <div className="h-full flex flex-col">
                <div className="p-2 border-b">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-semibold">Průzkumník souborů</h3>
                    <div className="flex items-center">
                      <Button variant="ghost" size="icon" title="Obnovit" onClick={fetchFileSystem}>
                        <RefreshCw className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" title="Nový soubor">
                        <PlusCircle className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input 
                      placeholder="Hledat soubory..." 
                      className="pl-8"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <ScrollArea className="flex-1">
                  <div className="p-2">
                    {renderFileTree(fileSystem)}
                  </div>
                </ScrollArea>
              </div>
            </ResizablePanel>
            
            <ResizableHandle />
            
            {/* Pravý panel - Editor a historie */}
            <ResizablePanel defaultSize={80}>
              <ResizablePanelGroup direction="vertical">
                {/* Horní panel - Editor kódu */}
                <ResizablePanel defaultSize={70}>
                  <div className="h-full flex flex-col">
                    <div className="border-b p-2 flex justify-between items-center">
                      <div className="flex items-center">
                        <Tabs defaultValue="code" value={activeEditorTab} onValueChange={setActiveEditorTab}>
                          <TabsList>
                            <TabsTrigger value="code">
                              <Code className="mr-2 h-4 w-4" />
                              Kód
                            </TabsTrigger>
                            <TabsTrigger value="terminal">
                              <Terminal className="mr-2 h-4 w-4" />
                              Terminál
                            </TabsTrigger>
                          </TabsList>
                        </Tabs>
                      </div>
                      <div>
                        {currentFile && (
                          <div className="flex items-center">
                            <span className="text-xs mr-2">
                              {currentFile.path}
                              {hasUnsavedChanges && " *"}
                            </span>
                            <Select 
                              value={fileLanguage} 
                              onValueChange={setFileLanguage}
                            >
                              <SelectTrigger className="h-8 w-[130px]">
                                <SelectValue placeholder="Jazyk" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="javascript">JavaScript</SelectItem>
                                <SelectItem value="typescript">TypeScript</SelectItem>
                                <SelectItem value="html">HTML</SelectItem>
                                <SelectItem value="css">CSS</SelectItem>
                                <SelectItem value="json">JSON</SelectItem>
                              </SelectContent>
                            </Select>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="ml-2"
                              onClick={saveCurrentFile}
                              disabled={!hasUnsavedChanges}
                            >
                              <Save className="h-4 w-4 mr-1" />
                              Uložit
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex-1 overflow-hidden">
                      <TabsContent value="code" className="h-full">
                        {currentFile ? (
                          <Textarea
                            className="w-full h-full resize-none rounded-none border-0 focus-visible:ring-0 focus-visible:ring-offset-0 font-mono"
                            placeholder="Vyberte soubor z průzkumníku na levé straně..."
                            value={code}
                            onChange={(e) => setCode(e.target.value)}
                          />
                        ) : (
                          <div className="h-full flex items-center justify-center text-muted-foreground">
                            <div className="text-center">
                              <FileCode className="h-12 w-12 mx-auto mb-2 opacity-50" />
                              <p>Vyberte soubor z průzkumníku na levé straně pro zobrazení a úpravu kódu</p>
                            </div>
                          </div>
                        )}
                      </TabsContent>
                      <TabsContent value="terminal" className="h-full">
                        <div className="bg-black text-white h-full p-4 font-mono text-sm">
                          <div>$ node crm-server.js</div>
                          <div>🚀 CRM server s AI modulem běží na adrese http://0.0.0.0:3000</div>
                          <div>📊 Prostředí: development</div>
                          <div>=======================================================</div>
                          <div className="mt-2">$</div>
                        </div>
                      </TabsContent>
                    </div>
                  </div>
                </ResizablePanel>
                
                <ResizableHandle />
                
                {/* Dolní panel - Historie změn */}
                <ResizablePanel defaultSize={30}>
                  <div className="h-full flex flex-col">
                    <div className="border-b p-2">
                      <div className="flex items-center">
                        <History className="h-4 w-4 mr-2" />
                        <h3 className="text-sm font-semibold">Historie změn</h3>
                      </div>
                    </div>
                    <ScrollArea className="flex-1">
                      <div className="p-2">
                        {history.map((item) => (
                          <div key={item.id} className="mb-4">
                            <div className="flex justify-between items-start mb-1">
                              <div className="font-medium">{item.description}</div>
                              <div className="text-xs text-muted-foreground">
                                {item.timestamp.toLocaleString()}
                              </div>
                            </div>
                            <div className="text-sm text-muted-foreground mb-1">
                              Uživatel: {item.user}
                            </div>
                            <div className="text-sm bg-muted p-2 rounded">
                              {item.changes}
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                </ResizablePanel>
              </ResizablePanelGroup>
            </ResizablePanel>
          </ResizablePanelGroup>
        </TabsContent>

        {/* AI Asistent */}
        <TabsContent value="ai" className="mt-0 h-full">
          <Card className="h-full border-0 rounded-none">
            <CardHeader>
              <CardTitle>AI Vývojářský Asistent</CardTitle>
              <CardDescription>
                Využijte sílu AI pro analýzu kódu, generování dokumentace, debugování a další úkoly
              </CardDescription>
            </CardHeader>
            <CardContent className="h-[calc(100%-120px)]">
              <Tabs defaultValue="code-analysis" value={activeAITab} onValueChange={setActiveAITab} className="h-full">
                <TabsList className="grid grid-cols-4 mb-4">
                  <TabsTrigger value="code-analysis">
                    <Code className="mr-2 h-4 w-4" />
                    Analýza kódu
                  </TabsTrigger>
                  <TabsTrigger value="documentation">
                    <FileText className="mr-2 h-4 w-4" />
                    Dokumentace
                  </TabsTrigger>
                  <TabsTrigger value="debug">
                    <Bug className="mr-2 h-4 w-4" />
                    Debug
                  </TabsTrigger>
                  <TabsTrigger value="feature">
                    <Sparkles className="mr-2 h-4 w-4" />
                    Generování funkcí
                  </TabsTrigger>
                </TabsList>

                <div className="h-[calc(100%-60px)] overflow-auto">
                  {/* Analýza kódu */}
                  <TabsContent value="code-analysis" className="h-full">
                    <div className="grid grid-cols-2 gap-4 h-full">
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Kód k analýze</label>
                          <Textarea
                            placeholder="Vložte svůj kód zde..."
                            className="min-h-[300px] font-mono"
                            value={codeToAnalyze}
                            onChange={(e) => setCodeToAnalyze(e.target.value)}
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <Button 
                            variant="outline"
                            onClick={() => {
                              if (currentFile) {
                                setCodeToAnalyze(code);
                              } else {
                                toast({
                                  title: "Upozornění",
                                  description: "Nejprve otevřete soubor v editoru",
                                });
                              }
                            }}
                          >
                            <Copy className="mr-2 h-4 w-4" />
                            Použít aktuální soubor
                          </Button>
                          <Button 
                            onClick={handleAnalyzeCode} 
                            disabled={analysisResult.isLoading}
                          >
                            {analysisResult.isLoading && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
                            Analyzovat kód
                          </Button>
                        </div>
                      </div>
                      <div className="border rounded-md p-4 overflow-auto">
                        <h3 className="font-semibold mb-2">Výsledky analýzy:</h3>
                        {analysisResult.isLoading ? (
                          <div className="flex justify-center items-center h-[300px]">
                            <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
                          </div>
                        ) : analysisResult.error ? (
                          <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-800">
                            {analysisResult.error}
                          </div>
                        ) : analysisResult.data ? (
                          <div className="whitespace-pre-line">{analysisResult.data}</div>
                        ) : (
                          <div className="text-muted-foreground italic">
                            Zde se zobrazí výsledky analýzy vašeho kódu...
                          </div>
                        )}
                      </div>
                    </div>
                  </TabsContent>

                  {/* Dokumentace */}
                  <TabsContent value="documentation" className="h-full">
                    <div className="grid grid-cols-2 gap-4 h-full">
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Kód pro dokumentaci</label>
                          <Textarea
                            placeholder="Vložte svůj kód zde..."
                            className="min-h-[300px] font-mono"
                            value={codeToDocument}
                            onChange={(e) => setCodeToDocument(e.target.value)}
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <Button 
                            variant="outline"
                            onClick={() => {
                              if (currentFile) {
                                setCodeToDocument(code);
                              } else {
                                toast({
                                  title: "Upozornění",
                                  description: "Nejprve otevřete soubor v editoru",
                                });
                              }
                            }}
                          >
                            <Copy className="mr-2 h-4 w-4" />
                            Použít aktuální soubor
                          </Button>
                          <Button 
                            onClick={handleGenerateDocumentation} 
                            disabled={documentationResult.isLoading}
                          >
                            {documentationResult.isLoading && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
                            Generovat dokumentaci
                          </Button>
                        </div>
                      </div>
                      <div className="border rounded-md p-4 overflow-auto">
                        <h3 className="font-semibold mb-2">Vygenerovaná dokumentace:</h3>
                        {documentationResult.isLoading ? (
                          <div className="flex justify-center items-center h-[300px]">
                            <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
                          </div>
                        ) : documentationResult.error ? (
                          <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-800">
                            {documentationResult.error}
                          </div>
                        ) : documentationResult.data ? (
                          <div className="whitespace-pre-line">{documentationResult.data}</div>
                        ) : (
                          <div className="text-muted-foreground italic">
                            Zde se zobrazí vygenerovaná dokumentace k vašemu kódu...
                          </div>
                        )}
                      </div>
                    </div>
                  </TabsContent>

                  {/* Debug */}
                  <TabsContent value="debug" className="h-full">
                    <div className="grid grid-cols-2 gap-4 h-full">
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Problematický kód</label>
                          <Textarea
                            placeholder="Vložte svůj kód zde..."
                            className="min-h-[200px] font-mono"
                            value={codeToDebug}
                            onChange={(e) => setCodeToDebug(e.target.value)}
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Chybová zpráva</label>
                          <Textarea
                            placeholder="Vložte chybovou zprávu zde..."
                            className="min-h-[100px]"
                            value={errorMessage}
                            onChange={(e) => setErrorMessage(e.target.value)}
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <Button 
                            variant="outline"
                            onClick={() => {
                              if (currentFile) {
                                setCodeToDebug(code);
                              } else {
                                toast({
                                  title: "Upozornění",
                                  description: "Nejprve otevřete soubor v editoru",
                                });
                              }
                            }}
                          >
                            <Copy className="mr-2 h-4 w-4" />
                            Použít aktuální soubor
                          </Button>
                          <Button 
                            onClick={handleDebugCode} 
                            disabled={debugResult.isLoading}
                          >
                            {debugResult.isLoading && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
                            Analyzovat a opravit
                          </Button>
                        </div>
                      </div>
                      <div className="border rounded-md p-4 overflow-auto">
                        <h3 className="font-semibold mb-2">Navrhované řešení:</h3>
                        {debugResult.isLoading ? (
                          <div className="flex justify-center items-center h-[300px]">
                            <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
                          </div>
                        ) : debugResult.error ? (
                          <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-800">
                            {debugResult.error}
                          </div>
                        ) : debugResult.data ? (
                          <div className="whitespace-pre-line">{debugResult.data}</div>
                        ) : (
                          <div className="text-muted-foreground italic">
                            Zde se zobrazí analýza a navrhované řešení vašeho problému...
                          </div>
                        )}
                      </div>
                    </div>
                  </TabsContent>

                  {/* Generování funkcí */}
                  <TabsContent value="feature" className="h-full">
                    <div className="grid grid-cols-2 gap-4 h-full">
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Popis funkcionality</label>
                          <Textarea
                            placeholder="Popište požadovanou funkcionalitu..."
                            className="min-h-[250px]"
                            value={featureDescription}
                            onChange={(e) => setFeatureDescription(e.target.value)}
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Framework</label>
                          <Select value={framework} onValueChange={setFramework}>
                            <SelectTrigger>
                              <SelectValue placeholder="Vyberte framework" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="react">React</SelectItem>
                              <SelectItem value="express">Express</SelectItem>
                              <SelectItem value="react+typescript">React + TypeScript</SelectItem>
                              <SelectItem value="express+typescript">Express + TypeScript</SelectItem>
                              <SelectItem value="vanilla">JavaScript (Vanilla)</SelectItem>
                              <SelectItem value="nodejs">Node.js</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <Button 
                          onClick={handleGenerateFeature} 
                          disabled={featureResult.isLoading}
                        >
                          {featureResult.isLoading && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
                          Generovat kód funkce
                        </Button>
                      </div>
                      <div className="border rounded-md p-4 overflow-auto">
                        <h3 className="font-semibold mb-2">Vygenerovaný kód:</h3>
                        {featureResult.isLoading ? (
                          <div className="flex justify-center items-center h-[300px]">
                            <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
                          </div>
                        ) : featureResult.error ? (
                          <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-800">
                            {featureResult.error}
                          </div>
                        ) : featureResult.data ? (
                          <div>
                            <pre className="overflow-auto p-4 bg-slate-900 text-slate-50 rounded-md">
                              {featureResult.data}
                            </pre>
                            <div className="mt-4 flex justify-end">
                              <Button 
                                variant="outline" 
                                onClick={() => {
                                  if (currentFile) {
                                    setCode(code + "\n\n" + featureResult.data);
                                    toast({
                                      title: "Kód přidán",
                                      description: "Vygenerovaný kód byl přidán do aktuálního souboru",
                                    });
                                  } else {
                                    toast({
                                      title: "Upozornění",
                                      description: "Nejprve otevřete soubor v editoru",
                                    });
                                  }
                                }}
                              >
                                <Copy className="mr-2 h-4 w-4" />
                                Přidat do aktuálního souboru
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="text-muted-foreground italic">
                            Zde se zobrazí vygenerovaný kód na základě vašeho popisu...
                          </div>
                        )}
                      </div>
                    </div>
                  </TabsContent>
                </div>
              </Tabs>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Náhled aplikace */}
        <TabsContent value="preview" className="mt-0 h-full">
          <div className="h-full flex flex-col">
            <div className="border-b p-2 flex justify-between items-center">
              <div className="flex items-center">
                <Eye className="h-4 w-4 mr-2" />
                <h3 className="text-sm font-semibold">Náhled aplikace</h3>
              </div>
              <div className="flex items-center">
                <div className="relative mr-2 w-[300px]">
                  <Input 
                    value={previewUrl} 
                    onChange={(e) => setPreviewUrl(e.target.value)}
                    className="h-8"
                  />
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={refreshPreview}
                  disabled={isPreviewLoading}
                >
                  {isPreviewLoading ? (
                    <RefreshCw className="h-4 w-4 animate-spin mr-1" />
                  ) : (
                    <RefreshCw className="h-4 w-4 mr-1" />
                  )}
                  Obnovit
                </Button>
              </div>
            </div>
            <div className="flex-1 p-4 bg-muted/30">
              <div className="w-full h-full bg-background rounded-md overflow-hidden border shadow-sm">
                <iframe 
                  ref={previewIframeRef}
                  src={previewUrl}
                  className="w-full h-full"
                  onLoad={handlePreviewLoad}
                />
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
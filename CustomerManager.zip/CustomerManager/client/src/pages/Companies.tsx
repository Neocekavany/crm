import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { DataTable } from "@/components/ui/data-table";
import { ColumnDef } from "@tanstack/react-table";
import { PlusCircle, Pencil, Trash2 } from "lucide-react";
import { Company } from "@shared/schema";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import CompanyForm from "@/components/company/CompanyForm";

export default function Companies() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [companyFormOpen, setCompanyFormOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [currentCompany, setCurrentCompany] = useState<Company | null>(null);
  
  const { data: companies, isLoading } = useQuery<Company[]>({
    queryKey: ['/api/companies'],
  });
  
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/companies/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/companies'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      toast({
        title: "Společnost smazána",
        description: "Společnost byla úspěšně odstraněna",
      });
      setDeleteDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Chyba při mazání společnosti",
        description: error instanceof Error ? error.message : "Neznámá chyba",
        variant: "destructive",
      });
    },
  });
  
  const handleDelete = (company: Company) => {
    setCurrentCompany(company);
    setDeleteDialogOpen(true);
  };
  
  const handleEdit = (company: Company) => {
    setCurrentCompany(company);
    setCompanyFormOpen(true);
  };
  
  const handleAdd = () => {
    setCurrentCompany(null);
    setCompanyFormOpen(true);
  };
  
  const confirmDelete = () => {
    if (currentCompany) {
      deleteMutation.mutate(currentCompany.id);
    }
  };
  
  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'client': return 'Klient';
      case 'prospect': return 'Prospekt';
      case 'lead': return 'Lead';
      default: return status;
    }
  };
  
  const getStatusVariant = (status: string) => {
    switch (status) {
      case 'client': return 'success';
      case 'prospect': return 'default';
      case 'lead': return 'warning';
      default: return 'secondary';
    }
  };
  
  const columns: ColumnDef<Company>[] = [
    {
      accessorKey: "name",
      header: "Společnost",
      cell: ({ row }) => {
        const company = row.original;
        const initial = company.name.charAt(0);
        
        return (
          <div className="flex items-center">
            <Avatar className="h-10 w-10 bg-primary/10 text-primary">
              <AvatarFallback>{initial}</AvatarFallback>
            </Avatar>
            <div className="ml-4">
              <div className="text-sm font-medium text-gray-900">{company.name}</div>
              <div className="text-sm text-gray-500">{company.industry}</div>
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: "info",
      header: "Informace",
      cell: ({ row }) => {
        const company = row.original;
        return (
          <div>
            <div className="text-sm text-gray-900">{company.address}</div>
            <div className="text-sm text-gray-500">{company.website}</div>
            <div className="text-sm text-gray-500">
              {company.employees} zaměstnanců • {company.revenue}
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: "contactPerson",
      header: "Kontaktní osoba",
      cell: ({ row }) => (
        <div className="text-sm text-gray-900">{row.original.contactPerson || '-'}</div>
      ),
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => {
        const status = row.original.status;
        return (
          <Badge variant={getStatusVariant(status) as any}>
            {getStatusLabel(status)}
          </Badge>
        );
      },
    },
    {
      id: "actions",
      header: () => <div className="text-right">Akce</div>,
      cell: ({ row }) => (
        <div className="flex justify-end gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              handleEdit(row.original);
            }}
          >
            <Pencil className="h-4 w-4 text-primary" />
            <span className="sr-only">Upravit</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              handleDelete(row.original);
            }}
          >
            <Trash2 className="h-4 w-4 text-red-600" />
            <span className="sr-only">Smazat</span>
          </Button>
        </div>
      ),
    },
  ];
  
  return (
    <>
      <div className="flex justify-end mb-4">
        <Button onClick={handleAdd}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Přidat společnost
        </Button>
      </div>
      
      <DataTable
        columns={columns}
        data={companies || []}
        searchPlaceholder="Hledat společnosti..."
        searchColumn="name"
        filterOptions={[
          {
            name: "Status",
            options: [
              { label: "Klient", value: "client" },
              { label: "Prospekt", value: "prospect" },
              { label: "Lead", value: "lead" },
            ],
            column: "status",
          },
        ]}
        onRowClick={handleEdit}
      />
      
      <CompanyForm
        open={companyFormOpen}
        company={currentCompany}
        onOpenChange={setCompanyFormOpen}
      />
      
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Opravdu chcete smazat tuto společnost?</AlertDialogTitle>
            <AlertDialogDescription>
              Tuto akci nelze vrátit zpět. Společnost bude trvale odstraněna z našeho systému.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Zrušit</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">
              Smazat
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

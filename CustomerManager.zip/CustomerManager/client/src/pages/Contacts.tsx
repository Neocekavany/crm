import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { DataTable } from "@/components/ui/data-table";
import { ColumnDef } from "@tanstack/react-table";
import { PlusCircle, Pencil, Trash2 } from "lucide-react";
import { Contact } from "@shared/schema";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { format } from "date-fns";
import { cs } from "date-fns/locale";
import ContactForm from "@/components/contact/ContactForm";
import { format as formatDate } from 'date-fns';

export default function Contacts() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [contactFormOpen, setContactFormOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [currentContact, setCurrentContact] = useState<Contact | null>(null);
  
  const { data: contacts, isLoading } = useQuery<Contact[]>({
    queryKey: ['/api/contacts'],
  });
  
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/contacts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/contacts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      toast({
        title: "Kontakt smazán",
        description: "Kontakt byl úspěšně odstraněn",
      });
      setDeleteDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Chyba při mazání kontaktu",
        description: error instanceof Error ? error.message : "Neznámá chyba",
        variant: "destructive",
      });
    },
  });
  
  const handleDelete = (contact: Contact) => {
    setCurrentContact(contact);
    setDeleteDialogOpen(true);
  };
  
  const handleEdit = (contact: Contact) => {
    setCurrentContact(contact);
    setContactFormOpen(true);
  };
  
  const handleAdd = () => {
    setCurrentContact(null);
    setContactFormOpen(true);
  };
  
  const confirmDelete = () => {
    if (currentContact) {
      deleteMutation.mutate(currentContact.id);
    }
  };
  
  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active': return 'Aktivní';
      case 'inactive': return 'Neaktivní';
      case 'lead': return 'Lead';
      default: return status;
    }
  };
  
  const getStatusVariant = (status: string) => {
    switch (status) {
      case 'active': return 'success';
      case 'inactive': return 'destructive';
      case 'lead': return 'warning';
      default: return 'secondary';
    }
  };
  
  const columns: ColumnDef<Contact>[] = [
    {
      accessorKey: "fullName",
      header: "Jméno",
      cell: ({ row }) => {
        const contact = row.original;
        const initials = `${contact.firstName.charAt(0)}${contact.lastName.charAt(0)}`;
        
        return (
          <div className="flex items-center">
            <Avatar className="h-10 w-10 bg-neutral-200 text-neutral-600">
              <AvatarFallback>{initials}</AvatarFallback>
            </Avatar>
            <div className="ml-4">
              <div className="text-sm font-medium text-gray-900">
                {contact.firstName} {contact.lastName}
              </div>
              <div className="text-sm text-gray-500">{contact.position}</div>
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: "contactInfo",
      header: "Kontaktní údaje",
      cell: ({ row }) => {
        const contact = row.original;
        return (
          <div>
            <div className="text-sm text-gray-900">{contact.email}</div>
            <div className="text-sm text-gray-500">{contact.phone}</div>
          </div>
        );
      },
    },
    {
      accessorKey: "company",
      header: "Společnost",
      cell: ({ row }) => (
        <div className="text-sm text-gray-900">{row.original.company}</div>
      ),
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => {
        const status = row.original.status;
        return (
          <Badge variant={getStatusVariant(status) as any}>
            {getStatusLabel(status)}
          </Badge>
        );
      },
    },
    {
      accessorKey: "lastContact",
      header: "Poslední kontakt",
      cell: ({ row }) => {
        const date = row.original.lastContact;
        return (
          <div className="text-sm text-gray-500">
            {date ? formatDate(new Date(date), 'dd.MM.yyyy') : '-'}
          </div>
        );
      },
    },
    {
      id: "actions",
      header: () => <div className="text-right">Akce</div>,
      cell: ({ row }) => (
        <div className="flex justify-end gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              handleEdit(row.original);
            }}
          >
            <Pencil className="h-4 w-4 text-primary" />
            <span className="sr-only">Upravit</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              handleDelete(row.original);
            }}
          >
            <Trash2 className="h-4 w-4 text-red-600" />
            <span className="sr-only">Smazat</span>
          </Button>
        </div>
      ),
    },
  ];
  
  return (
    <>
      <div className="flex justify-end mb-4">
        <Button onClick={handleAdd}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Přidat kontakt
        </Button>
      </div>
      
      <DataTable
        columns={columns}
        data={contacts || []}
        searchPlaceholder="Hledat kontakty..."
        searchColumn="fullName"
        filterOptions={[
          {
            name: "Status",
            options: [
              { label: "Aktivní", value: "active" },
              { label: "Neaktivní", value: "inactive" },
              { label: "Lead", value: "lead" },
            ],
            column: "status",
          },
        ]}
        onRowClick={handleEdit}
      />
      
      <ContactForm
        open={contactFormOpen}
        contact={currentContact}
        onOpenChange={setContactFormOpen}
      />
      
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Opravdu chcete smazat tento kontakt?</AlertDialogTitle>
            <AlertDialogDescription>
              Tuto akci nelze vrátit zpět. Kontakt bude trvale odstraněn z našeho systému.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Zrušit</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">
              Smazat
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

/**
 * API middleware pro komunikaci s OpenAI
 * Všechny koncové body jsou chráněné autentizací
 */
const express = require('express');
const OpenAI = require('openai');

// Inicializace OpenAI API s klíčem ze systémových proměnných
// Nejnovější model OpenAI je "gpt-4o", vydaný 13. května 2024
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const router = express.Router();

// Middleware pro ověření, že uživatel je přihlášen
const isAuthenticated = (req, res, next) => {
  if (req.session && req.session.user) {
    return next();
  }
  res.status(401).json({ error: 'Neautorizovaný přístup', success: false });
};

// Všechny API endpointy jsou chráněny autentizací
router.use(isAuthenticated);

/**
 * Analyzuje kód a poskytne rady na zlepšení
 */
router.post('/analyze-code', async (req, res) => {
  try {
    const { code } = req.body;
    
    if (!code) {
      return res.status(400).json({ error: 'Kód je povinný parametr', success: false });
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Jsi pokročilý kódový analytik. Proveď revizi kódu a nabídni konkrétní zlepšení zaměřená na výkon, bezpečnost a čitelnost."
        },
        {
          role: "user",
          content: `Analyzuj následující kód a poskytni konstruktivní zpětnou vazbu:\n\n${code}`
        }
      ],
    });

    res.json({ 
      result: response.choices[0].message.content,
      success: true
    });
  } catch (error) {
    console.error('Chyba při analýze kódu:', error);
    res.status(500).json({ 
      error: 'Nepodařilo se analyzovat kód. Zkontrolujte API klíč nebo připojení.',
      success: false 
    });
  }
});

/**
 * Generuje dokumentaci pro kód
 */
router.post('/generate-documentation', async (req, res) => {
  try {
    const { code } = req.body;
    
    if (!code) {
      return res.status(400).json({ error: 'Kód je povinný parametr', success: false });
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Jsi specialista na dokumentaci kódu. Vytvoř podrobnou dokumentaci s popisem funkcionality, parametrů, návratových hodnot a příkladů použití."
        },
        {
          role: "user",
          content: `Vygeneruj dokumentaci pro následující kód:\n\n${code}`
        }
      ],
    });

    res.json({ 
      result: response.choices[0].message.content,
      success: true
    });
  } catch (error) {
    console.error('Chyba při generování dokumentace:', error);
    res.status(500).json({ 
      error: 'Nepodařilo se vygenerovat dokumentaci. Zkontrolujte API klíč nebo připojení.',
      success: false 
    });
  }
});

/**
 * Pomáhá řešit problémy s kódem
 */
router.post('/debug-code', async (req, res) => {
  try {
    const { code, errorMessage } = req.body;
    
    if (!code) {
      return res.status(400).json({ error: 'Kód je povinný parametr', success: false });
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Jsi zkušený debugger. Analyzuj zdrojový kód a související chybové zprávy, identifikuj problémy a navrhni opravy."
        },
        {
          role: "user",
          content: `Pomoz mi opravit tento kód. ${errorMessage ? `Chybová zpráva: "${errorMessage}"` : ''}\n\nZdrojový kód:\n\n${code}`
        }
      ],
    });

    res.json({ 
      result: response.choices[0].message.content,
      success: true
    });
  } catch (error) {
    console.error('Chyba při debugování kódu:', error);
    res.status(500).json({ 
      error: 'Nepodařilo se debugovat kód. Zkontrolujte API klíč nebo připojení.',
      success: false 
    });
  }
});

/**
 * Generuje nové funkce nebo komponenty na základě popisu
 */
router.post('/generate-feature', async (req, res) => {
  try {
    const { description, framework } = req.body;
    
    if (!description) {
      return res.status(400).json({ error: 'Popis funkcionality je povinný parametr', success: false });
    }

    const frameworkType = framework || 'javascript';

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `Jsi expert na vývoj v ${frameworkType}. Vytvoř kód, který splňuje zadané požadavky s důrazem na efektivitu, bezpečnost a moderní praktiky.`
        },
        {
          role: "user",
          content: `Vytvoř ${frameworkType} komponentu/funkci podle tohoto popisu: "${description}"`
        }
      ],
    });

    res.json({ 
      result: response.choices[0].message.content,
      success: true
    });
  } catch (error) {
    console.error('Chyba při generování funkce:', error);
    res.status(500).json({ 
      error: 'Nepodařilo se vygenerovat funkci. Zkontrolujte API klíč nebo připojení.',
      success: false 
    });
  }
});

/**
 * Obecný dotaz na AI asistenta
 */
router.post('/ask-question', async (req, res) => {
  try {
    const { query } = req.body;
    
    if (!query) {
      return res.status(400).json({ error: 'Dotaz je povinný parametr', success: false });
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Jsi pomocník pro vývojáře, zaměřený na programování a technické informace. Poskytuj jasné, informativní a stručné odpovědi v českém jazyce."
        },
        {
          role: "user",
          content: query
        }
      ],
    });

    res.json({ 
      result: response.choices[0].message.content,
      success: true
    });
  } catch (error) {
    console.error('Chyba při dotazu:', error);
    res.status(500).json({ 
      error: 'Nepodařilo se získat odpověď. Zkontrolujte API klíč nebo připojení.',
      success: false 
    });
  }
});

/**
 * Generuje testovací případy pro zadaný kód
 */
router.post('/generate-tests', async (req, res) => {
  try {
    const { code, testFramework } = req.body;
    
    if (!code) {
      return res.status(400).json({ error: 'Kód je povinný parametr', success: false });
    }

    const framework = testFramework || 'jest';

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `Jsi specialista na testování s frameworkem ${framework}. Vytvoř komplexní sadu testů pro poskytnutý kód, pokrývající různé scénáře včetně hraničních případů a ošetření chyb.`
        },
        {
          role: "user",
          content: `Vygeneruj testy v ${framework} pro následující kód:\n\n${code}`
        }
      ],
    });

    res.json({ 
      result: response.choices[0].message.content,
      success: true
    });
  } catch (error) {
    console.error('Chyba při generování testů:', error);
    res.status(500).json({ 
      error: 'Nepodařilo se vygenerovat testy. Zkontrolujte API klíč nebo připojení.',
      success: false 
    });
  }
});

/**
 * API pro práci se souborovým systémem - pouze demonstrační pro vývojářský panel
 */
router.get('/file-system', async (req, res) => {
  try {
    const fs = require('fs');
    const path = require('path');
    const rootDir = process.cwd();
    
    // Funkce pro rekurzivní získání struktury adresářů a souborů
    const getDirectoryTree = (dir, basePath = '') => {
      const items = fs.readdirSync(dir, { withFileTypes: true });
      const result = [];
      
      for (const item of items) {
        const relativePath = path.join(basePath, item.name);
        const fullPath = path.join(dir, item.name);
        
        // Ignorujeme skryté soubory a složky
        if (item.name.startsWith('.')) continue;
        
        if (item.isDirectory()) {
          result.push({
            id: Buffer.from(relativePath).toString('base64'),
            name: item.name,
            type: 'directory',
            path: relativePath,
            children: getDirectoryTree(fullPath, relativePath)
          });
        } else {
          // Detekce typu jazyka podle přípony
          const ext = path.extname(item.name).toLowerCase();
          let language = 'text';
          
          if (['.js', '.mjs', '.cjs'].includes(ext)) language = 'javascript';
          else if (['.ts', '.tsx'].includes(ext)) language = 'typescript';
          else if (['.jsx'].includes(ext)) language = 'jsx';
          else if (['.html', '.htm'].includes(ext)) language = 'html';
          else if (['.css'].includes(ext)) language = 'css';
          else if (['.json'].includes(ext)) language = 'json';
          else if (['.php'].includes(ext)) language = 'php';
          else if (['.py'].includes(ext)) language = 'python';
          else if (['.java'].includes(ext)) language = 'java';
          else if (['.cpp', '.c', '.h', '.hpp'].includes(ext)) language = 'cpp';
          
          result.push({
            id: Buffer.from(relativePath).toString('base64'),
            name: item.name,
            type: 'file',
            path: relativePath,
            language
          });
        }
      }
      
      return result;
    };
    
    try {
      // Omezíme hloubku procházení pro lepší výkon
      const fileTree = getDirectoryTree(rootDir).slice(0, 50);
      res.json({
        data: fileTree,
        success: true
      });
    } catch (fsError) {
      console.error('Chyba při čtení adresářové struktury:', fsError);
      // Fallback na demonstrační data
      res.json({
        data: [
          {
            id: '1',
            name: 'server',
            type: 'directory',
            path: '/server',
            children: [
              {
                id: '11',
                name: 'routes.js',
                type: 'file',
                path: '/server/routes.js',
                language: 'javascript'
              },
              {
                id: '12',
                name: 'db.js',
                type: 'file',
                path: '/server/db.js',
                language: 'javascript'
              }
            ]
          },
          {
            id: '2',
            name: 'client',
            type: 'directory',
            path: '/client',
            children: [
              {
                id: '21',
                name: 'src',
                type: 'directory',
                path: '/client/src',
                children: [
                  {
                    id: '211',
                    name: 'App.jsx',
                    type: 'file',
                    path: '/client/src/App.jsx',
                    language: 'jsx'
                  }
                ]
              }
            ]
          }
        ],
        success: true
      });
    }
  } catch (error) {
    console.error('Chyba při získávání struktury souborů:', error);
    res.status(500).json({ 
      error: 'Nepodařilo se získat strukturu souborů',
      success: false 
    });
  }
});

/**
 * API pro získání obsahu souboru
 */
router.get('/file-content', async (req, res) => {
  try {
    const fs = require('fs');
    const path = require('path');
    const { filePath } = req.query;
    
    if (!filePath) {
      return res.status(400).json({ 
        error: 'Cesta k souboru je povinný parametr',
        success: false 
      });
    }
    
    const rootDir = process.cwd();
    const fullPath = path.join(rootDir, filePath);
    
    // Bezpečnostní kontrola - soubor musí být pod kořenovým adresářem
    const relativePath = path.relative(rootDir, fullPath);
    if (relativePath.startsWith('..') || path.isAbsolute(relativePath)) {
      return res.status(403).json({
        error: 'Přístup odepřen: Pokus o přístup mimo povolený adresář',
        success: false
      });
    }
    
    try {
      // Pokusíme se přečíst soubor
      const content = fs.readFileSync(fullPath, 'utf-8');
      
      // Detekce typu jazyka
      const ext = path.extname(fullPath).toLowerCase();
      let language = 'text';
      
      if (['.js', '.mjs', '.cjs'].includes(ext)) language = 'javascript';
      else if (['.ts', '.tsx'].includes(ext)) language = 'typescript';
      else if (['.jsx'].includes(ext)) language = 'jsx';
      else if (['.html', '.htm'].includes(ext)) language = 'html';
      else if (['.css'].includes(ext)) language = 'css';
      else if (['.json'].includes(ext)) language = 'json';
      else if (['.php'].includes(ext)) language = 'php';
      else if (['.py'].includes(ext)) language = 'python';
      else if (['.java'].includes(ext)) language = 'java';
      else if (['.cpp', '.c', '.h', '.hpp'].includes(ext)) language = 'cpp';
      
      res.json({
        content,
        language,
        path: filePath,
        success: true
      });
    } catch (fsError) {
      console.error('Chyba při čtení souboru:', fsError);
      // Fallback demo obsah
      res.json({
        content: `// Ukázkový obsah souboru pro cestu: ${filePath}\n// Soubor nebyl nalezen nebo k němu nemáte přístup.\nconsole.log('Hello world!');`,
        language: 'javascript',
        path: filePath,
        success: true
      });
    }
  } catch (error) {
    console.error('Chyba při čtení souboru:', error);
    res.status(500).json({ 
      error: 'Nepodařilo se přečíst soubor',
      success: false 
    });
  }
});

module.exports = router;
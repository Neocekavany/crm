#!/bin/bash

echo "Setting up test data for CRM system..."

# Run the script with TypeScript
npx tsx setup-test-data.ts

echo "Setup completed!"
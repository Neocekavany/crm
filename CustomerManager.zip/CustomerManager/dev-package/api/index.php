<?php
/**
 * API Endpoint pro vývojářské prostředí
 * Zpracovává všechny požadavky na AI funkce
 */

// Nastavení hlaviček
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

// Pro OPTIONS požadavky (CORS) vrátíme pouze hlavičky
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit;
}

// Ověření přihlášení
session_start();
$isLoggedIn = isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0;

if (!$isLoggedIn) {
    echo json_encode([
        'error' => 'Nejste přihlášeni',
        'success' => false
    ]);
    exit;
}

// Načtení OpenAI API klíče z konfigurace nebo proměnné prostředí
$openaiApiKey = getenv('OPENAI_API_KEY') ?: '';

if (empty($openaiApiKey)) {
    echo json_encode([
        'error' => 'OpenAI API klíč není nastaven',
        'success' => false
    ]);
    exit;
}

// Parsování URL pro určení koncového bodu API
$requestPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$basePath = '/api/';
$endpoint = str_replace($basePath, '', $requestPath);

// Načtení těla požadavku pro POST metody
$requestBody = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requestBody = json_decode(file_get_contents('php://input'), true);
}

// Hlavní funkce pro komunikaci s OpenAI API
function callOpenAI($messages, $model = 'gpt-4o') {
    global $openaiApiKey;
    
    $ch = curl_init();
    
    curl_setopt($ch, CURLOPT_URL, 'https://api.openai.com/v1/chat/completions');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $openaiApiKey
    ]);
    
    $data = [
        'model' => $model,
        'messages' => $messages,
        'temperature' => 0.7
    ];
    
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    
    $response = curl_exec($ch);
    $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    curl_close($ch);
    
    if ($statusCode !== 200) {
        $error = json_decode($response, true);
        throw new Exception($error['error']['message'] ?? 'Chyba při komunikaci s OpenAI API');
    }
    
    return json_decode($response, true);
}

// Zpracování požadavku podle endpointu
try {
    switch ($endpoint) {
        // Analýza kódu
        case 'analyze-code':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Metoda není povolena');
            }
            
            if (empty($requestBody['code'])) {
                throw new Exception('Kód je povinný parametr');
            }
            
            $code = $requestBody['code'];
            
            $messages = [
                ['role' => 'system', 'content' => 'Jsi pokročilý kódový analytik. Proveď revizi kódu a nabídni konkrétní zlepšení zaměřená na výkon, bezpečnost a čitelnost. Odpovídej v češtině.'],
                ['role' => 'user', 'content' => "Analyzuj následující kód a poskytni konstruktivní zpětnou vazbu:\n\n$code"]
            ];
            
            $openaiResponse = callOpenAI($messages);
            
            echo json_encode([
                'result' => $openaiResponse['choices'][0]['message']['content'],
                'success' => true
            ]);
            break;
            
        // Generování dokumentace
        case 'generate-documentation':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Metoda není povolena');
            }
            
            if (empty($requestBody['code'])) {
                throw new Exception('Kód je povinný parametr');
            }
            
            $code = $requestBody['code'];
            
            $messages = [
                ['role' => 'system', 'content' => 'Jsi specialista na dokumentaci kódu. Vytvoř podrobnou dokumentaci s popisem funkcionality, parametrů, návratových hodnot a příkladů použití. Odpovídej v češtině.'],
                ['role' => 'user', 'content' => "Vygeneruj dokumentaci pro následující kód:\n\n$code"]
            ];
            
            $openaiResponse = callOpenAI($messages);
            
            echo json_encode([
                'result' => $openaiResponse['choices'][0]['message']['content'],
                'success' => true
            ]);
            break;
            
        // Debugging kódu
        case 'debug-code':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Metoda není povolena');
            }
            
            if (empty($requestBody['code'])) {
                throw new Exception('Kód je povinný parametr');
            }
            
            $code = $requestBody['code'];
            $errorMessage = $requestBody['errorMessage'] ?? '';
            
            $userContent = "Pomoz mi opravit tento kód.";
            if (!empty($errorMessage)) {
                $userContent .= " Chybová zpráva: \"$errorMessage\"";
            }
            $userContent .= "\n\nZdrojový kód:\n\n$code";
            
            $messages = [
                ['role' => 'system', 'content' => 'Jsi zkušený debugger. Analyzuj zdrojový kód a související chybové zprávy, identifikuj problémy a navrhni opravy. Odpovídej v češtině.'],
                ['role' => 'user', 'content' => $userContent]
            ];
            
            $openaiResponse = callOpenAI($messages);
            
            echo json_encode([
                'result' => $openaiResponse['choices'][0]['message']['content'],
                'success' => true
            ]);
            break;
            
        // Generování funkce
        case 'generate-feature':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Metoda není povolena');
            }
            
            if (empty($requestBody['description'])) {
                throw new Exception('Popis funkcionality je povinný parametr');
            }
            
            $description = $requestBody['description'];
            $framework = $requestBody['framework'] ?? 'javascript';
            
            $messages = [
                ['role' => 'system', 'content' => "Jsi expert na vývoj v $framework. Vytvoř kód, který splňuje zadané požadavky s důrazem na efektivitu, bezpečnost a moderní praktiky. Odpovídej v češtině."],
                ['role' => 'user', 'content' => "Vytvoř $framework komponentu/funkci podle tohoto popisu: \"$description\""]
            ];
            
            $openaiResponse = callOpenAI($messages);
            
            echo json_encode([
                'result' => $openaiResponse['choices'][0]['message']['content'],
                'success' => true
            ]);
            break;
            
        // Otázka na AI
        case 'ask-question':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Metoda není povolena');
            }
            
            if (empty($requestBody['query'])) {
                throw new Exception('Dotaz je povinný parametr');
            }
            
            $query = $requestBody['query'];
            
            $messages = [
                ['role' => 'system', 'content' => 'Jsi pomocník pro vývojáře, zaměřený na programování a technické informace. Poskytuj jasné, informativní a stručné odpovědi v českém jazyce.'],
                ['role' => 'user', 'content' => $query]
            ];
            
            $openaiResponse = callOpenAI($messages);
            
            echo json_encode([
                'result' => $openaiResponse['choices'][0]['message']['content'],
                'success' => true
            ]);
            break;
            
        // Generování testů
        case 'generate-tests':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Metoda není povolena');
            }
            
            if (empty($requestBody['code'])) {
                throw new Exception('Kód je povinný parametr');
            }
            
            $code = $requestBody['code'];
            $testFramework = $requestBody['testFramework'] ?? 'jest';
            
            $messages = [
                ['role' => 'system', 'content' => "Jsi specialista na testování s frameworkem $testFramework. Vytvoř komplexní sadu testů pro poskytnutý kód, pokrývající různé scénáře včetně hraničních případů a ošetření chyb. Odpovídej v češtině."],
                ['role' => 'user', 'content' => "Vygeneruj testy v $testFramework pro následující kód:\n\n$code"]
            ];
            
            $openaiResponse = callOpenAI($messages);
            
            echo json_encode([
                'result' => $openaiResponse['choices'][0]['message']['content'],
                'success' => true
            ]);
            break;
            
        // Získání struktury souborů
        case 'file-system':
            if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
                throw new Exception('Metoda není povolena');
            }
            
            // Kořenový adresář pro prohlížení souborů (upravte podle vaší struktury)
            $rootDir = realpath(__DIR__ . '/../..');
            
            // Funkce pro rekurzivní získání struktury adresářů a souborů
            function getDirectoryTree($dir, $basePath = '') {
                $items = [];
                
                if (!is_dir($dir)) {
                    return $items;
                }
                
                $files = scandir($dir);
                
                foreach ($files as $file) {
                    // Přeskočit skryté soubory a speciální adresáře
                    if ($file[0] === '.' || $file === 'vendor' || $file === 'node_modules') {
                        continue;
                    }
                    
                    $path = $dir . '/' . $file;
                    $relativePath = $basePath ? $basePath . '/' . $file : $file;
                    
                    if (is_dir($path)) {
                        // Omezení hloubky zanořování pro výkon
                        if (substr_count($relativePath, '/') < 3) {
                            $children = getDirectoryTree($path, $relativePath);
                            $items[] = [
                                'id' => base64_encode($relativePath),
                                'name' => $file,
                                'type' => 'directory',
                                'path' => $relativePath,
                                'children' => $children
                            ];
                        } else {
                            $items[] = [
                                'id' => base64_encode($relativePath),
                                'name' => $file,
                                'type' => 'directory',
                                'path' => $relativePath,
                                'children' => []
                            ];
                        }
                    } else {
                        // Detekce typu jazyka podle přípony
                        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                        $language = 'text';
                        
                        if (in_array($ext, ['js', 'mjs', 'cjs'])) $language = 'javascript';
                        else if (in_array($ext, ['ts', 'tsx'])) $language = 'typescript';
                        else if ($ext === 'jsx') $language = 'jsx';
                        else if (in_array($ext, ['html', 'htm'])) $language = 'html';
                        else if ($ext === 'css') $language = 'css';
                        else if ($ext === 'json') $language = 'json';
                        else if ($ext === 'php') $language = 'php';
                        else if ($ext === 'py') $language = 'python';
                        else if ($ext === 'java') $language = 'java';
                        else if (in_array($ext, ['cpp', 'c', 'h', 'hpp'])) $language = 'cpp';
                        
                        $items[] = [
                            'id' => base64_encode($relativePath),
                            'name' => $file,
                            'type' => 'file',
                            'path' => $relativePath,
                            'language' => $language
                        ];
                    }
                }
                
                return $items;
            }
            
            try {
                $fileTree = getDirectoryTree($rootDir);
                echo json_encode([
                    'data' => array_slice($fileTree, 0, 50), // Omezení počtu položek pro výkon
                    'success' => true
                ]);
            } catch (Exception $e) {
                // Fallback - ukázková data pro demonstraci
                echo json_encode([
                    'data' => [
                        [
                            'id' => base64_encode('www'),
                            'name' => 'www',
                            'type' => 'directory',
                            'path' => 'www',
                            'children' => [
                                [
                                    'id' => base64_encode('www/index.php'),
                                    'name' => 'index.php',
                                    'type' => 'file',
                                    'path' => 'www/index.php',
                                    'language' => 'php'
                                ],
                                [
                                    'id' => base64_encode('www/js'),
                                    'name' => 'js',
                                    'type' => 'directory',
                                    'path' => 'www/js',
                                    'children' => [
                                        [
                                            'id' => base64_encode('www/js/main.js'),
                                            'name' => 'main.js',
                                            'type' => 'file',
                                            'path' => 'www/js/main.js',
                                            'language' => 'javascript'
                                        ]
                                    ]
                                ]
                            ]
                        ]
                    ],
                    'success' => true
                ]);
            }
            break;
            
        // Získání obsahu souboru
        case 'file-content':
            if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
                throw new Exception('Metoda není povolena');
            }
            
            if (empty($_GET['filePath'])) {
                throw new Exception('Cesta k souboru je povinný parametr');
            }
            
            $filePath = $_GET['filePath'];
            $rootDir = realpath(__DIR__ . '/../..');
            $fullPath = realpath($rootDir . '/' . $filePath);
            
            // Bezpečnostní kontrola - soubor musí být pod kořenovým adresářem
            if (!$fullPath || strpos($fullPath, $rootDir) !== 0) {
                throw new Exception('Přístup odepřen: Pokus o přístup mimo povolený adresář');
            }
            
            if (!file_exists($fullPath) || !is_file($fullPath)) {
                throw new Exception('Soubor neexistuje');
            }
            
            // Detekce typu jazyka podle přípony
            $ext = strtolower(pathinfo($fullPath, PATHINFO_EXTENSION));
            $language = 'text';
            
            if (in_array($ext, ['js', 'mjs', 'cjs'])) $language = 'javascript';
            else if (in_array($ext, ['ts', 'tsx'])) $language = 'typescript';
            else if ($ext === 'jsx') $language = 'jsx';
            else if (in_array($ext, ['html', 'htm'])) $language = 'html';
            else if ($ext === 'css') $language = 'css';
            else if ($ext === 'json') $language = 'json';
            else if ($ext === 'php') $language = 'php';
            else if ($ext === 'py') $language = 'python';
            else if ($ext === 'java') $language = 'java';
            else if (in_array($ext, ['cpp', 'c', 'h', 'hpp'])) $language = 'cpp';
            
            $content = file_get_contents($fullPath);
            
            echo json_encode([
                'content' => $content,
                'language' => $language,
                'path' => $filePath,
                'success' => true
            ]);
            break;
            
        // Uložení obsahu souboru
        case 'save-file':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Metoda není povolena');
            }
            
            if (empty($requestBody['path'])) {
                throw new Exception('Cesta k souboru je povinný parametr');
            }
            
            if (!isset($requestBody['content'])) {
                throw new Exception('Obsah souboru je povinný parametr');
            }
            
            $filePath = $requestBody['path'];
            $content = $requestBody['content'];
            
            $rootDir = realpath(__DIR__ . '/../..');
            $fullPath = realpath($rootDir . '/' . $filePath);
            
            // Bezpečnostní kontrola - soubor musí být pod kořenovým adresářem
            if (!$fullPath || strpos($fullPath, $rootDir) !== 0) {
                throw new Exception('Přístup odepřen: Pokus o přístup mimo povolený adresář');
            }
            
            if (!file_exists($fullPath) || !is_file($fullPath)) {
                throw new Exception('Soubor neexistuje');
            }
            
            if (!is_writable($fullPath)) {
                throw new Exception('Soubor nelze zapisovat - zkontrolujte oprávnění');
            }
            
            file_put_contents($fullPath, $content);
            
            echo json_encode([
                'message' => 'Soubor byl úspěšně uložen',
                'success' => true
            ]);
            break;
            
        default:
            throw new Exception('Neznámý endpoint: ' . $endpoint);
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'error' => $e->getMessage(),
        'success' => false
    ]);
}
?>
<?php
/**
 * Vývojářský systém pro JN Ventures
 * Hlavní soubor - spouští vývojářské prostředí
 */

// Kontrola přihlášení (napojení na váš existující systém)
session_start();
$isLoggedIn = isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0;

// Redirect na přihlášení, pokud uživatel není přihlášen
if (!$isLoggedIn && !isset($_GET['login'])) {
    header('Location: index.php?login=1');
    exit;
}

// Konfigurace API klíčů - nahraďte svými skutečnými hodnotami
$config = [
    'openai_api_key' => getenv('OPENAI_API_KEY') ?: '', // Pro nasazení použijte proměnnou prostředí
    'site_url' => 'https://www.jnventures.cz',
    'admin_email' => 'admin@jnventures.cz'
];

// Přihlašovací formulář, pokud uživatel není přihlášen
if (!$isLoggedIn && isset($_GET['login'])) {
    // Zpracování přihlášení
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        
        // Zde nahraďte svým vlastním ověřovacím mechanismem
        if ($username === 'admin' && $password === 'password') {
            $_SESSION['user_id'] = 1;
            $_SESSION['username'] = $username;
            header('Location: index.php');
            exit;
        } else {
            $error = 'Nesprávné přihlašovací údaje';
        }
    }
    
    // Zobrazení přihlašovacího formuláře
    ?>
    <!DOCTYPE html>
    <html lang="cs">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Přihlášení - Vývojářský systém JN Ventures</title>
        <link rel="stylesheet" href="public/css/style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body class="login-page">
        <div class="login-container">
            <div class="login-header">
                <h1>Vývojářský systém</h1>
                <p>JN Ventures</p>
            </div>
            
            <?php if (isset($error)): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <form method="post" action="index.php?login=1" class="login-form">
                <div class="form-group">
                    <label for="username"><i class="fa fa-user"></i> Uživatelské jméno</label>
                    <input type="text" id="username" name="username" required autocomplete="username">
                </div>
                
                <div class="form-group">
                    <label for="password"><i class="fa fa-lock"></i> Heslo</label>
                    <input type="password" id="password" name="password" required autocomplete="current-password">
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn-primary">
                        <i class="fa fa-sign-in"></i> Přihlásit se
                    </button>
                </div>
            </form>
        </div>
        
        <script src="public/js/main.js"></script>
    </body>
    </html>
    <?php
    exit;
}

// Hlavní vývojářské prostředí pro přihlášené uživatele
?>
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vývojářské prostředí JN Ventures</title>
    <meta name="description" content="Pokročilé vývojářské prostředí s umělou inteligencí pro efektivní správu kódu a vývoj aplikací.">
    <meta property="og:title" content="Vývojářské prostředí JN Ventures">
    <meta property="og:description" content="Pokročilé vývojářské prostředí s umělou inteligencí pro efektivní správu kódu a vývoj aplikací.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://www.jnventures.cz/dev-system/">
    
    <link rel="stylesheet" href="public/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/styles/default.min.css">
</head>
<body class="dev-system-page">
    <header class="main-header">
        <div class="logo">
            <a href="<?php echo htmlspecialchars($config['site_url']); ?>">
                <span class="logo-text">JN Ventures</span>
            </a>
        </div>
        
        <nav class="main-nav">
            <ul>
                <li><a href="<?php echo htmlspecialchars($config['site_url']); ?>"><i class="fa fa-home"></i> Hlavní stránka</a></li>
                <li><a href="<?php echo htmlspecialchars($config['site_url']); ?>/admin/"><i class="fa fa-dashboard"></i> Admin Panel</a></li>
                <li class="active"><a href="#"><i class="fa fa-code"></i> Vývojářské prostředí</a></li>
                <li><a href="?logout=1"><i class="fa fa-sign-out"></i> Odhlásit se</a></li>
            </ul>
        </nav>
    </header>

    <div id="dev-system-root" class="dev-system-container">
        <div class="loading-screen">
            <div class="spinner"></div>
            <p>Načítám vývojářské prostředí...</p>
        </div>
    </div>

    <!-- Skryté nastavení pro klientský JavaScript -->
    <script>
        // Konfigurace pro vývojářské prostředí
        window.DEV_SYSTEM_CONFIG = {
            apiBaseUrl: 'api',
            username: '<?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'uživatel'; ?>',
            userAvatar: 'public/img/user-avatar.png',
            defaultLanguage: 'javascript',
            theme: 'dark' // Možnosti: 'light', 'dark', 'system'
        };
    </script>

    <!-- Externí knihovny -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/highlight.min.js"></script>
    
    <!-- Vlastní skripty -->
    <script src="public/js/lib/utils.js"></script>
    <script src="public/js/lib/file-system.js"></script>
    <script src="public/js/lib/ai-service.js"></script>
    <script src="public/js/dev-system.js"></script>
    <script src="public/js/main.js"></script>
    
    <script>
        // Inicializace aplikace
        document.addEventListener('DOMContentLoaded', function() {
            DevSystem.init('dev-system-root');
        });
    </script>
</body>
</html>